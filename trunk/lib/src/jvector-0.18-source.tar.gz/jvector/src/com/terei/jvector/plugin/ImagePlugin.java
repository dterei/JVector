/*
 * Created By David Terei
 * With the Eclispe IDE
 * 
 * Created on 1/06/2004
 */
package com.terei.jvector.plugin;

import java.io.File;

import javax.swing.filechooser.FileFilter;

import com.terei.jvector.paint.ImageFile;


/**
 * An interface that must be extended to create a class to
 * save JVector image to other various image formats (eg JPG).
 * 
 * @author David Terei
 * @version 1
 * @since JVector 0.16 (1/06/2004)
 */
public interface ImagePlugin {
    
    /**
     * Get the File Extension of the Image's
     * outputted by the plugin.
     * 
     * @return The Image Extension.
     */
    public String getExtension();
    
    /**
     * Get the extension for this image type.
     * 
     * @return The extension of the image type.
     */
    public FileFilter getFileFilter();   
    
    /**
     * Save the image to the file specified.
     * 
     * @param image The image to save.
     * @param file The file to save it to.
     * @return If the operation succeeded.
     */
    public boolean save(ImageFile image, File file);
    
}
