/*
 * Created By David Terei
 * With the Eclispe IDE
 * 
 * Created on 1/06/2004
 */
package com.terei.jvector.plugin;

import java.awt.RenderingHints;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;

import javax.swing.filechooser.FileFilter;

import org.apache.batik.svggen.SVGGraphics2D;
import org.apache.batik.dom.GenericDOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.DOMImplementation;

import com.terei.jvector.GUI.SwingFileFilter;
import com.terei.jvector.paint.ImageFile;
import com.terei.jvector.paint.shapes.Shape;


/**
 * @author David Terei
 * @version 1
 * @since 1/06/2004
 */
public class SvgPlugin implements ImagePlugin {   
    
    private static final String IMAGE_EXT = "svg";
    
    private static final String IMAGE_DES = "SVG Image Format (." 
        											+ IMAGE_EXT + ")";
    
    /* (non-Javadoc)
     * @see com.terei.jvector.plugin.ImagePlugin#getExtension()
     */
    public String getExtension() {
        return IMAGE_EXT;
    }

    /* (non-Javadoc)
     * @see com.terei.jvector.plugin.ImagePlugin#getFileFilter()
     */
    public FileFilter getFileFilter() {
        return new SwingFileFilter(IMAGE_EXT, IMAGE_DES, true);
    }
    
    /* (non-Javadoc)
     * @see com.terei.jvector.plugin.ImagePlugin#save(com.terei.jvector.paint.ImageFile, java.io.File)
     */
    public boolean save(ImageFile image, File file) {
        //get the shapes to paint.
        Shape[] shapes = image.shapes;
        
        //Get a DOMImplementation
        DOMImplementation domImpl =
            GenericDOMImplementation.getDOMImplementation();

        //Create an instance of org.w3c.dom.Document
        Document document = domImpl.createDocument(null, IMAGE_EXT, null);
        
        //Create an instance of the SVG Generator
        SVGGraphics2D svgGenerator = new SVGGraphics2D(document);
        
        //turn Antialiasing on.
    	svgGenerator.setRenderingHint(RenderingHints.KEY_ANTIALIASING, 
    	        RenderingHints.VALUE_ANTIALIAS_ON);
    	
    	//draw all the shapes.
    	for(int i=0; i<shapes.length; i++)
    		shapes[i].paint(svgGenerator);
    	
    	//check its got the image extension
    	String name = file.getName();
    	
    	if (!name.endsWith("."+IMAGE_EXT)) {
            String path = file.getAbsolutePath()+"."+IMAGE_EXT;
            file = new File(path);
        }
    	
    	//Finally, stream out SVG to the standard output using UTF-8
    	//character to byte encoding    	
    	try {
    	    boolean useCSS = true; // we want to use CSS style attribute
    	    FileOutputStream fos = new FileOutputStream(file);
    	    Writer out = new OutputStreamWriter(fos, "UTF-8");
    	    svgGenerator.stream(out, useCSS);
    	    //svgGenerator.stream(file.getAbsolutePath());
    	} catch (Exception e) {
    	    System.err.println("Exception saving image: " + e);
    	}
        
        return true;
    }

}
