/*
 * Created By David Terei
 * With the Eclispe IDE
 * 
 * Created on 1/06/2004
 */
package com.terei.jvector.plugin;

import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.filechooser.FileFilter;

import com.terei.jvector.GUI.SwingFileFilter;
import com.terei.jvector.paint.ImageFile;
import com.terei.jvector.paint.shapes.Shape;


/**
 * @author David Terei
 * @version 1
 * @since 1/06/2004
 */
public class JpgPlugin implements ImagePlugin {
    
    /**
     * The extnesion of this image type.
     */
    public static final String IMAGE_EXT = "jpg";
    
    private static final String IMAGE_DES = "JPG Image Format (." 
											+ JpgPlugin.IMAGE_EXT + ")";
    
    /* (non-Javadoc)
     * @see com.terei.jvector.plugin.ImagePlugin#getExtension()
     */
    public String getExtension() {
        return IMAGE_EXT;
    }
    
    /* (non-Javadoc)
     * @see com.terei.jvector.plugin.ImagePlugin#getFileFilter()
     */
    public FileFilter getFileFilter() {
        return new SwingFileFilter(IMAGE_EXT, IMAGE_DES, true);
    }

    /* (non-Javadoc)
     * @see com.terei.jvector.plugin.ImagePlugin#save(com.terei.jvector.paint.ImageFile)
     */
    public boolean save(ImageFile image, File file) {
        //create a bufferedimage to draw the jvector image to.
        //well then save this buffered image.
        BufferedImage bi = new BufferedImage(image.width, image.height, 
                BufferedImage.TYPE_INT_ARGB);               
        
        //get the buffered image's graphics to paint the jvector
        //image to.
        Graphics2D g = (Graphics2D)bi.getGraphics();
        //get the shapes to paint.
        Shape[] shapes = image.shapes;
        
        //turn Antialiasing on.
    	g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    	
    	//draw all the shapes.
    	for(int i=0; i<shapes.length; i++)
    		shapes[i].paint(g);
        
    	//check its got the image extension
    	String name = file.getName();
    	
    	if (!name.endsWith("."+IMAGE_EXT)) {
            String path = file.getAbsolutePath()+"."+IMAGE_EXT;
            file = new File(path);
        }
    	
    	//save the image
    	try {
    	    ImageIO.write(bi, IMAGE_EXT, file);
    	} catch (IOException e) {
    	    System.err.println("IOException Saving Image: " + e);
    	}
    	
    	
        return true;
    }
        
}
