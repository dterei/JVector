/*
 * Created By David Terei
 * With the Eclispe IDE
 * 
 * Created on 26/12/03.
 */
package com.terei.jvector.language;

import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
* This class provides one easy static method to load the
* currently set language file for the program specified.
*
* @author David Terei
* @since 26/12/03
* @version 1
*/
public class LangLoader {

  /**
   * Dont Allow Contrsuction
   */
  private LangLoader() {
  }

  /**
   * Loads the language bundle specified, looking in
   * the languages program, relative to the program root.
   * The locale to load is specified in the lang.properties
   * file in the prgoram root\class path.
   * For example,
   *
   * <p><Center><Dir>%PROGRAM_CLASSPATH%\Languages\%bundle%</Dir></Center>
   * This is the path of the file it will atempt to load.</p>
   *
   * @param bundle the resurce bundle to load.
   *          %PROGRAM_CLASSPATH\Languages\%bundle%
   * @return The resource bundle requested in the locale
   *      specified in the %PROGRAM_CLASSPATH\lang.properties
   *      file.
   */
  public static ResourceBundle getLocale(String bundle) {
      //Load the properties file, lang.
      ResourceBundle defLang = ResourceBundle.getBundle("lang");
      //Setup some strings to hold the Locale data.
      String LangCode = "";
      String ConCode = "";
      try {
          //Get the locale Langauge code.
          LangCode = defLang.getString("Language.Code");
          //Get the Locale Country code.
          ConCode = defLang.getString("Country.Code");
      } catch (MissingResourceException e) {
          //Catch any exceptions.
          e.printStackTrace();
      }
      //get the current langauge Locale data.
      ResourceBundle ret = ResourceBundle.getBundle( "Languages."
                                      + bundle, new Locale(LangCode, ConCode) );

      return ret;
  }

}
