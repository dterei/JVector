#include <process.h> 

int main(void) { 
    
    execlp("java.exe", "java.exe", "-cp", "JVector.exe", 
                            "com.terei.jvector.JVector", 0); 
    
    return 0; 
} 
