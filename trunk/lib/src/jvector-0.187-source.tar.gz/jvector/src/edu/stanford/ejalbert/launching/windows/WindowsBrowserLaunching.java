package edu.stanford.ejalbert.launching.windows;

import edu.stanford.ejalbert.exception.BrowserLaunchingInitializingException;
import edu.stanford.ejalbert.launching.IBrowserLaunching;

/**
 * @author Markus Gebhard
 */
public abstract class WindowsBrowserLaunching implements IBrowserLaunching {
  public void initialize() throws BrowserLaunchingInitializingException {
  }
}
