package edu.stanford.ejalbert.launching.macos;

import edu.stanford.ejalbert.launching.IBrowserLaunching;

/**
 * @author Markus Gebhard
 */
public abstract class MacOsBrowserLaunching implements IBrowserLaunching {

  /**
   * The creator code of the Finder on a Macintosh, which is needed to send AppleEvents to the
   * application.
   */
  protected static final String FINDER_CREATOR = "MACS";
}