package edu.stanford.ejalbert.launching.misc;

import edu.stanford.ejalbert.exception.BrowserLaunchingExecutionException;
import edu.stanford.ejalbert.exception.BrowserLaunchingInitializingException;
import edu.stanford.ejalbert.launching.IBrowserLaunching;

/**
 * Assume that we're on Unix and that Netscape is installed
 * @author Markus Gebhard
 */
public class UnixNetscapeBrowserLaunching implements IBrowserLaunching {
  private final static String browser = "netscape";

  /**
   * The shell parameters for Netscape that opens a given URL in an already-open copy of Netscape
   * on many command-line systems.
   */
  private static final String NETSCAPE_REMOTE_PARAMETER = "-remote";
  private static final String NETSCAPE_OPEN_PARAMETER_START = "'openURL(";
  private static final String NETSCAPE_OPEN_PARAMETER_END = ")'";

  public void initialize() throws BrowserLaunchingInitializingException {
  }

  public void openUrl(String urlString) throws BrowserLaunchingExecutionException {
    try {
      Process process =
        Runtime.getRuntime().exec(
          new String[] {
            browser,
            NETSCAPE_REMOTE_PARAMETER,
            NETSCAPE_OPEN_PARAMETER_START + urlString + NETSCAPE_OPEN_PARAMETER_END });
      int exitCode = process.waitFor();
      if (exitCode != 0) { // if Netscape was not open
        Runtime.getRuntime().exec(new String[] { browser, urlString });
      }
    }
    catch (Exception e) {
      throw new BrowserLaunchingExecutionException(e);
    }
  }
}