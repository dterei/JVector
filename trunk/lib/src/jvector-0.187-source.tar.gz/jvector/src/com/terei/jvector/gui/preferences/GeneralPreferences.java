/*
 * Created By David Terei
 * With the Eclispe IDE
 * 
 * Created on 17/06/2004
 */
package com.terei.jvector.gui.preferences;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.util.MissingResourceException;
import java.util.Properties;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import com.terei.jvector.JVector;


/**
 * A JPanel for the preferences dialog which displays some general options
 * about JVector.
 * 
 * @author David Terei
 * @version 1
 * @since 17/06/2004
 */
public class GeneralPreferences extends PreferencePanel implements ChangeListener {

    /**
     * The max value the slider can be for the mouse double click speed.
     */
    private static final int MOUSE_SPEED_MIN = 50;
    
    /**
     * The min value the slider can be for the mouse double click speed.
     */
    private static final int MOUSE_SPEED_MAX = 800;
    
    /**
     * The title of this JPanel.
     */
    private String title = "General";
    
    /**
     * The JSlider that allows the user to set there mouse double click speed.
     */
    private JSlider slider;
    
    /**
     * The Text Label that displays the double click value
     */
    private JLabel field = new JLabel("200");
    
    /**
     * Construct a new Startup JPanel.
     * 
     * @param props The properties file where this information is stored.
     */
    public GeneralPreferences(Properties props) {
        title = JVector.getRBLocale().getString("Dialog.Preferences.General");
        initPanel(props);
    }
    
    /**
     * Constructs the GUI of the panel.
     * 
     * @param props The Properties File to use to setup the GUI, as it will display
     * these properties.
     */
    public void initPanel(Properties props) {
        this.setLayout(new FlowLayout(FlowLayout.LEFT));
        this.add(new JLabel(JVector.getRBLocale().
                getString("Dialog.Preferences.General.MouseSpeed")));
        
        int current = 200;
        try {
        	current = Integer.parseInt(props.getProperty("DoubleClick"));
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        
        slider = new JSlider(JSlider.HORIZONTAL, MOUSE_SPEED_MIN,
                		MOUSE_SPEED_MAX, current);
        slider.setPreferredSize(new Dimension(200,40));
        slider.addChangeListener(this);
        
        field.setText(String.valueOf(current));
        
        this.add(slider);
        this.add(field);
    }
    
    /**
     * Get the Title of this JPanel.
     * 
     * @return The title of the JPanel.
     */
    public String toString() {
        return title;
    }
    
    /* (non-Javadoc)
     * @see com.terei.jvector.gui.preferences.PreferencePanel#getBanner()
     */
    public ImageIcon getBanner() {
        ImageIcon icon = null;
        
        try {
            icon = JVector.loadImageIcon("Resources/preferences_general.png");
        } catch (MissingResourceException e) {
            e.printStackTrace();
        }
        
        return icon;
    }

    /* (non-Javadoc)
     * @see com.terei.jvector.gui.preferences.PreferencePanel#getProperties()
     */
    public Properties getProperties() {
        int speed = slider.getValue();
        
        Properties props = new Properties();
        props.setProperty("DoubleClick", String.valueOf(speed));
        return props;
    }
    
    /* (non-Javadoc)
     * @see javax.swing.event.ChangeListener#stateChanged(javax.swing.event.ChangeEvent)
     */
    public void stateChanged(ChangeEvent e) {
        JSlider source = (JSlider)e.getSource();
        int value = (int)source.getValue();
        field.setText(String.valueOf(value));
    }

}
