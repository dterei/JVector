/*
 * Copyright 2004 David Terei
 * 
 * This file is part of JVector.
 * 
 * JVector is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 * 
 * JVector is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with JVector; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.terei.jvector.gui;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JWindow;

import org.apache.log4j.Logger;

import com.terei.jvector.JVector;

/**
 * A Window that displays an 'about' [JVector] box.
 * 
 * @author David Terei
 * @version 1
 * @since 15/06/2004
 */
public class AboutDialog extends JWindow implements MouseListener {
    
    /**
     * Log4J Logger for this class
     */
    private static final Logger logger = Logger.getLogger(AboutDialog.class);
    
    /**
     * The dimensions of this dialog
     */
    private static final Dimension SIZE = new Dimension(300, 400);
    
    /**
     * The image to paint for the aboout dialog.
     */
    private static final ImageIcon image = JVector
    				.loadImageIcon("Resources/about.png");  
    
    /**
     * Construct a new About Dialog.
     *
     */
    public AboutDialog() {
        this.addMouseListener(this);
        
        JLabel label = new JLabel(image);
        getContentPane().add(label);
        
        pack();
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        int x = (int)(dim.width - this.getWidth())/2;
        int y = (int)(dim.height - this.getHeight())/2 - 60;
        setLocation(x,y);
    }

    /* (non-Javadoc)
     * @see java.awt.event.MouseListener#mouseClicked(java.awt.event.MouseEvent)
     */
    public void mouseClicked(MouseEvent arg0) {
        this.dispose();
    }

    /* (non-Javadoc)
     * @see java.awt.event.MouseListener#mouseEntered(java.awt.event.MouseEvent)
     */
    public void mouseEntered(MouseEvent arg0) {        
    }

    /* (non-Javadoc)
     * @see java.awt.event.MouseListener#mouseExited(java.awt.event.MouseEvent)
     */
    public void mouseExited(MouseEvent arg0) {        
    }

    /* (non-Javadoc)
     * @see java.awt.event.MouseListener#mousePressed(java.awt.event.MouseEvent)
     */
    public void mousePressed(MouseEvent arg0) {        
    }

    /* (non-Javadoc)
     * @see java.awt.event.MouseListener#mouseReleased(java.awt.event.MouseEvent)
     */
    public void mouseReleased(MouseEvent arg0) {        
    }
    
}