/*
 * Copyright 2004 David Terei
 * 
 * This file is part of JVector.
 * 
 * JVector is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * JVector is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with JVector; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package com.terei.jvector.language;

import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
* This class provides one easy static method to load the
* currently set language file for the program specified.
*
* @author David Terei
* @since 26/12/03
* @version 1
*/
public class LangLoader {

  /**
   * Dont Allow Contrsuction
   */
  private LangLoader() {
  }

  /**
   * Loads the language bundle specified, looking in
   * the languages program, relative to the program root.
   * The locale to load is specified in the lang.properties
   * file in the prgoram root\class path.
   * For example,
   *
   * <p><Center><Dir>%PROGRAM_CLASSPATH%\Languages\%bundle%</Dir></Center>
   * This is the path of the file it will atempt to load.</p>
   *
   * @param bundle the resurce bundle to load.
   *          %PROGRAM_CLASSPATH\Languages\%bundle%
   * @return The resource bundle requested in the locale
   *      specified in the %PROGRAM_CLASSPATH\lang.properties
   *      file.
   */
  public static ResourceBundle getLocale(String bundle) {
      //Load the properties file, lang.
      ResourceBundle defLang = ResourceBundle.getBundle("lang");
      //Setup some strings to hold the Locale data.
      String LangCode = "";
      String ConCode = "";
      try {
          //Get the locale Langauge code.
          LangCode = defLang.getString("Language.Code");
          //Get the Locale Country code.
          ConCode = defLang.getString("Country.Code");
      } catch (MissingResourceException e) {
          //Catch any exceptions.
          e.printStackTrace();
      }
      //get the current langauge Locale data.
      ResourceBundle ret = ResourceBundle.getBundle( "Languages."
                                      + bundle, new Locale(LangCode, ConCode) );

      return ret;
  }

}
