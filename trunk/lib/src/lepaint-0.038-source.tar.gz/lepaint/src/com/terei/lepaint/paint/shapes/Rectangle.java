/*
 * Created By David Terei
 * With the Eclispe IDE
 * Created on 2/05/2004
 */
package com.terei.lepaint.paint.shapes;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;


/**
 * This class stores all the information about a rectangle, and manages
 * its drawing.
 * 
 * @author David Terei
 * @since 2/05/2004
 * @version 0.3
 */
public class Rectangle extends Shape {
    
    /**
     * The top left coordiante of the rectangle.
     */
    private Point2D.Double p1;
    /**
     * The dimensions (width, height) of the rectangle.
     */
    private Point2D.Double dim;
    /**
	 * The outline colour of the rectangle.
	 */ 
    private Color c_out = Color.gray;
    /**
     * The fill colour of the rectangle.
     */
    private Color c_in = Color.black;
    /**
     * The stroke/width of the outline of the rectangle.
     */
    private int stroke = 1;
    
    /**
     * Create a new Rectangle.
     * 
     * @param p1 The top left coordiantes of the rectangle.
     * @param Stroke The stroke/width of the outline of the rectangle.
     */
    public Rectangle(Point2D.Double p1, int Stroke) {
        this(p1,new Point2D.Double(0,0),Stroke);        
    }
    
    /**
     * Create a new Rectangle.
     * 
     * @param p1 The top left coordiantes of the rectangle.
     * @param dim The dimensions (width, height) of the rectangle.
     * @param Stroke The stroke/width of the outline of the rectangle.     
     */    
    public Rectangle(Point2D.Double p1, Point2D.Double dim, int Stroke) {
        this.p1 = p1;
        this.dim = dim;
        stroke = Stroke;
    }
    
    /**
	 * Get the outline colour of the rectangle.
	 *
	 * @return The outline colour of the rectangle.
	 */
    public Color getOutlineColor() {
    	return c_out;
    }

    /**
	 * Get the fill colour of the rectangle.
	 *
	 * @return The fill colour of the rectangle.
	 */    
    public Color getFillColor() {
        return c_in;
    }

    /* (non-Javadoc)
     * @see com.terei.lepaint.paint.shapes.Shape#getShape()
     */
    public String getShape() {
        return "Rectangle";
    }
    
    /**
	 * Set the outline colour of the rectangle.
	 *
	 * @param color The colour to set it to.
	 */
    public void setOutlineColor(Color color) {
        c_out = color;
    }

    /**
	 * Set the fill colour of the rectangle.
	 *
	 * @param color The colour to set it to.
	 */
	 public void setFillColor(Color color) {
	 	c_in = color;
	 }
    
    /**
     * Sets the point starting point (top left).
     * 
     * @param p The point to set it to.
     */    
    public void setP1(Point2D.Double p) {
        p1 = new Point2D.Double(p.x,p.y);       
    }
    
    /**
     * Sets the point diagonally opptisote the starting point of the line (top left).
     * 
     * @param p2 The point to set it to.
     */
    public void setP2(Point2D.Double p2) {
        dim.x = p2.x - p1.x;
        dim.y = p2.y - p1.y;       
    }
    
    /* (non-Javadoc)
     * @see com.terei.lepaint.paint.shapes.Shape#paint(java.awt.Graphics)
     */
    public void paint(Graphics2D g) {
        //create a new rectangle to draw.
        Rectangle2D.Double rect = new Rectangle2D.Double(p1.x,p1.y,dim.x,dim.y);
        
        //draw the fill.
        g.setColor(c_in);
        g.fill(rect);
        //draw the outline.
        g.setStroke(new BasicStroke(stroke));        
        g.setColor(c_out);
        g.draw(rect);
    }
}
