import java.awt.FlowLayout;
import javax.swing.JPanel;
import java.awt.GridLayout;
import javax.swing.JButton;
import java.awt.BorderLayout;

/**
* This code was generated using CloudGarden's Jigloo
* SWT/Swing GUI Builder, which is free for non-commercial
* use. If Jigloo is being used commercially (ie, by a
* for-profit company or business) then you should purchase
* a license - please visit www.cloudgarden.com for details.
*/
public class NewJPanel extends javax.swing.JPanel {

	private JButton jButton34;
	private JButton jButton33;
	private JPanel jPanel2;
	private JButton jButton32;
	private JButton jButton31;
	private JButton jButton30;
	private JButton jButton29;
	private JButton jButton28;
	private JButton jButton27;
	private JButton jButton26;
	private JButton jButton25;
	private JButton jButton24;
	private JButton jButton23;
	private JButton jButton22;
	private JButton jButton21;
	private JButton jButton20;
	private JButton jButton19;
	private JButton jButton18;
	private JButton jButton17;
	private JButton jButton16;
	private JButton jButton15;
	private JButton jButton14;
	private JButton jButton13;
	private JButton jButton12;
	private JButton jButton11;
	private JButton jButton10;
	private JButton jButton9;
	private JButton jButton8;
	private JButton jButton7;
	private JButton jButton6;
	private JButton jButton5;
	private JButton jButton4;
	private JButton jButton3;
	private JButton jButton2;
	private JButton jButton1;
	private JPanel jPanel1;
	public NewJPanel() {
		initGUI();
	}

	/**
	* Initializes the GUI.
	* Auto-generated code - any changes you make will disappear.
	*/
	public void initGUI(){
		try {
			preInitGUI();
			jPanel2 = new JPanel();
			jButton33 = new JButton();
			jButton34 = new JButton();
			jPanel1 = new JPanel();
			jButton1 = new JButton();
			jButton2 = new JButton();
			jButton3 = new JButton();
			jButton4 = new JButton();
			jButton5 = new JButton();
			jButton6 = new JButton();
			jButton7 = new JButton();
			jButton8 = new JButton();
			jButton9 = new JButton();
			jButton10 = new JButton();
			jButton11 = new JButton();
			jButton12 = new JButton();
			jButton13 = new JButton();
			jButton14 = new JButton();
			jButton15 = new JButton();
			jButton16 = new JButton();
			jButton17 = new JButton();
			jButton18 = new JButton();
			jButton19 = new JButton();
			jButton20 = new JButton();
			jButton21 = new JButton();
			jButton22 = new JButton();
			jButton23 = new JButton();
			jButton24 = new JButton();
			jButton25 = new JButton();
			jButton26 = new JButton();
			jButton27 = new JButton();
			jButton28 = new JButton();
			jButton29 = new JButton();
			jButton30 = new JButton();
			jButton31 = new JButton();
			jButton32 = new JButton();
			BorderLayout thisLayout = new BorderLayout();
			this.setLayout(thisLayout);
			thisLayout.setHgap(0);
			thisLayout.setVgap(0);
			this.setBackground(new java.awt.Color(0,0,255));
			this.setPreferredSize(new java.awt.Dimension(201,227));
			FlowLayout jPanel2Layout = new FlowLayout();
			jPanel2.setLayout(jPanel2Layout);
			jPanel2Layout.setAlignment(FlowLayout.CENTER);
			jPanel2Layout.setHgap(5);
			jPanel2Layout.setVgap(5);
			this.add(jPanel2, BorderLayout.SOUTH);
			jButton33.setText("jButton33");
			jButton33.setPreferredSize(new java.awt.Dimension(34,10));
			jPanel2.add(jButton33);
			jButton34.setText("jButton34");
			jPanel2.add(jButton34);
			GridLayout jPanel1Layout = new GridLayout(10,10);
			jPanel1.setLayout(jPanel1Layout);
			jPanel1Layout.setRows(10);
			jPanel1Layout.setHgap(0);
			jPanel1Layout.setVgap(0);
			jPanel1Layout.setColumns(10);
			jPanel1.setPreferredSize(new java.awt.Dimension(201,165));
			this.add(jPanel1, BorderLayout.CENTER);
			jButton1.setText("jButton1");
			jButton1.setBackground(new java.awt.Color(255,128,128));
			jPanel1.add(jButton1);
			jButton2.setText("jButton2");
			jButton2.setBackground(new java.awt.Color(255,255,128));
			jPanel1.add(jButton2);
			jButton3.setText("jButton3");
			jButton3.setBackground(new java.awt.Color(128,255,128));
			jPanel1.add(jButton3);
			jButton4.setText("jButton4");
			jButton4.setBackground(new java.awt.Color(0,255,128));
			jPanel1.add(jButton4);
			jButton5.setText("jButton5");
			jButton5.setBackground(new java.awt.Color(128,255,255));
			jPanel1.add(jButton5);
			jButton6.setText("jButton6");
			jButton6.setBackground(new java.awt.Color(0,128,255));
			jButton6.setAutoscrolls(false);
			jPanel1.add(jButton6);
			jButton7.setText("jButton7");
			jButton7.setBackground(new java.awt.Color(255,128,192));
			jPanel1.add(jButton7);
			jButton8.setText("jButton8");
			jButton8.setBackground(new java.awt.Color(255,128,255));
			jButton8.setAutoscrolls(true);
			jPanel1.add(jButton8);
			jButton9.setText("jButton9");
			jButton9.setBackground(new java.awt.Color(255,0,0));
			jPanel1.add(jButton9);
			jButton10.setText("jButton10");
			jButton10.setBackground(new java.awt.Color(255,255,0));
			jPanel1.add(jButton10);
			jButton11.setText("jButton11");
			jButton11.setBackground(new java.awt.Color(128,255,0));
			jPanel1.add(jButton11);
			jButton12.setText("jButton12");
			jButton12.setBackground(new java.awt.Color(0,255,64));
			jPanel1.add(jButton12);
			jButton13.setText("jButton13");
			jButton13.setBackground(new java.awt.Color(0,255,255));
			jButton13.setPreferredSize(new java.awt.Dimension(50,20));
			jPanel1.add(jButton13);
			jButton14.setText("jButton14");
			jButton14.setBackground(new java.awt.Color(0,128,192));
			jPanel1.add(jButton14);
			jButton15.setText("jButton15");
			jButton15.setBackground(new java.awt.Color(128,128,192));
			jPanel1.add(jButton15);
			jButton16.setText("jButton16");
			jButton16.setBackground(new java.awt.Color(255,0,255));
			jPanel1.add(jButton16);
			jButton17.setText("jButton17");
			jPanel1.add(jButton17);
			jButton18.setText("jButton18");
			jPanel1.add(jButton18);
			jButton19.setText("jButton19");
			jPanel1.add(jButton19);
			jButton20.setText("jButton20");
			jPanel1.add(jButton20);
			jButton21.setText("jButton21");
			jPanel1.add(jButton21);
			jButton22.setText("jButton22");
			jPanel1.add(jButton22);
			jButton23.setText("jButton23");
			jPanel1.add(jButton23);
			jButton24.setText("jButton24");
			jPanel1.add(jButton24);
			jButton25.setText("jButton25");
			jPanel1.add(jButton25);
			jButton26.setText("jButton26");
			jPanel1.add(jButton26);
			jButton27.setText("jButton27");
			jPanel1.add(jButton27);
			jButton28.setText("jButton28");
			jPanel1.add(jButton28);
			jButton29.setText("jButton29");
			jPanel1.add(jButton29);
			jButton30.setText("jButton30");
			jPanel1.add(jButton30);
			jButton31.setText("jButton31");
			jPanel1.add(jButton31);
			jButton32.setText("jButton32");
			jPanel1.add(jButton32);
	
			postInitGUI();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/** Add your pre-init code in here 	*/
	public void preInitGUI(){
	}

	/** Add your post-init code in here 	*/
	public void postInitGUI(){
	}

	/** Auto-generated main method */
	public static void main(String[] args){
		showGUI();
	}

	/**
	* Auto-generated code - any changes you make will disappear!!!
	* This static method creates a new instance of this class and shows
	* it inside a new JFrame, (unless it is already a JFrame).
	*/
	public static void showGUI(){
		try {
			javax.swing.JFrame frame = new javax.swing.JFrame();
			NewJPanel inst = new NewJPanel();
			frame.setContentPane(inst);
			frame.getContentPane().setSize(inst.getSize());
			frame.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
			frame.pack();
			frame.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
