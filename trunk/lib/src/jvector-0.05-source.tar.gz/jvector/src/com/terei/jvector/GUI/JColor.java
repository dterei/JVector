/*
 * Created By David Terei
 * With the Eclispe IDE
 * 
 * Created on 12/05/2004
 */
package com.terei.jvector.GUI;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JComponent;
import javax.swing.border.LineBorder;


/**
 * 
 * 
 * @author David Terei
 * @since 12/05/2004
 * @version 0.1
 */
public class JColor extends JComponent {
    
    private Color color = Color.WHITE;
    
    public JColor(int r, int g, int b) {
        this(new Color(r,g,b));
    }
    
    public JColor(Color color) {
        this.color = color;        
        this.setBorder(new LineBorder(Color.black, 1, false));
    }
    
    public void paintComponent(Graphics g) {
        Dimension size = this.getSize();
        g.setColor(color);
        g.fillRect(0, 0, size.width, size.height);
    }
    
    public Color getColor() {
        return color;
    }
    
    public void setColor(Color color) {
        Color oldValue = this.color;
        this.color = color;
        
        this.firePropertyChange("color", oldValue, color);
        
        repaint();
    }
    
}

