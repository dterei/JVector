/*
 * Created By David Terei
 * With the Eclispe IDE
 * 
 * Created on 12/05/2004
 */
package com.terei.jvector.GUI;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;

import com.terei.jvector.JVector;


/**
 * 
 * 
 * @author David Terei
 * @since 12/05/2004
 * @version 0.1
 */
public class ColorSelectedPanel extends JPanel implements ActionListener {   
    
    private static JColor jcFore;
    
    private static JColor jcBack;
    
    private static JButton switcher;
    
    static {
        try {
            jcFore = new JColor(Color.black);
            jcFore.setBounds(0,0,30,30);
        
            jcBack = new JColor(Color.white);
            jcBack.setBounds(17,17,30,30);
            
            switcher = new JButton(JVector.loadImageIcon("Resources/switcher.png"));
            switcher.setContentAreaFilled(false);
            switcher.setBounds(32,0,16,16);            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public ColorSelectedPanel() {
        
        this.setLayout(null);
        this.setBounds(0,0,80,80);
        this.setMaximumSize(new Dimension(80,80));
        this.setPreferredSize(new Dimension(80,80));
        this.setMinimumSize(new Dimension(80,80));
        
        switcher.addActionListener(this);
        
        this.add(switcher);
        this.add(jcFore);
        this.add(jcBack);
        
    }
    
    protected static void setColor(Color color) {
        jcFore.setColor(color);        
    }
    
    public static Color getForeColor() {
        return jcFore.getColor();
    }
    
    public static Color getBackColor() {
        return jcBack.getColor();
    }
    
    public static boolean swapForeBack() {
        System.out.println("SWAP!");
        Color cFore = jcFore.getColor();
        Color cBack = jcBack.getColor();
        
        jcFore.setColor(cBack);
        jcBack.setColor(cFore);
        
        return true;
    }

    /* (non-Javadoc)
     * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
     */
    public void actionPerformed(ActionEvent e) {
        Object src = e.getSource();
        
        System.out.println("HIT");
        
        //if (src.equals(switcher))
        	ColorSelectedPanel.swapForeBack();
        	                
    }
}

