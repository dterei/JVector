/*
 * Created By David Terei
 * With the Eclispe IDE
 * Created on 25/04/2004
 */
package com.terei.jvector.paint.shapes;

import java.awt.Color;
import java.awt.Graphics2D;


/**
 * Lays a few basic properties/methods that all shapes must have.
 * All drawing shapes subclass this class.
 * 
 * @author David Terei
 * @since 25/04/2004
 * @version 0.5
 */
public abstract class Shape {
    
    /**
     * Returns the color of the shape.
     * 
     * @return The color of the shape.
     */
    public Color getColor() {
        return null;
    }
    
    /**
     * Returns the name of the shape.
     * 
     * @return The name of the shape.
     */
    public String getShape() {
        return "Shape";
    }

    /**
     * Sets the color of the shape.
     * 
     * @param color The color to set the shape to.
     */
    public void setColor(Color color) {
        
    }
    
    /**
     * The painting method for each shape.
     * 
     * @param g
     */
    public void paint(Graphics2D g) {
        
    }
    
}
