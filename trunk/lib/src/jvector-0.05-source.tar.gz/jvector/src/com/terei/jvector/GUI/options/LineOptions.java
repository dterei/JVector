/*
 * Created By David Terei
 * With the Eclispe IDE
 * Created on 26/04/2004
 */
package com.terei.jvector.GUI.options;

import java.awt.FlowLayout;
import java.text.ParseException;
import java.util.ResourceBundle;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;


/**
 * Creates a JPanel that gives the user access to several options to use when
 * drawing a line.
 * 
 * @author David Terei
 * @since 26/04/2004
 * @version 0.6
 */
public class LineOptions extends JPanel {

    /**
     * The stroke of the line.
     */
    public static int STROKE = 1;
    
    /**
     * The JSpiner that allows the user to pick the stroke.
     */
    private static JSpinner spinner;
    
    /**
     * Setup the JSpinner, spinner.
     */
    static {
        int value = 1;
        int min = 1;
        int max = 100;
        int step = 1;
        try {
            SpinnerNumberModel model = new SpinnerNumberModel(value, min, max, step);
            spinner = new JSpinner(model);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Create a new LineOptions, the constructor does most the
     * work as most of it is GUI work.
     */
    public LineOptions(ResourceBundle rbLocale) {
        this.setLayout(new FlowLayout());
        this.add(new JLabel(rbLocale.getString("ExtraBar.Line.Weight")));
        this.add(spinner);
    }
    
    /**
     * Get the stroke set. (the weight/thickness of the line)
     * 
     * @return The stroke (weight).
     */
    public static int getStroke() {
        if (spinner!=null) {
            try {
                //this set the currently edited value in the spinner, to
                //the spinner value, so that the user doesnt need to press
                //enter to apply their manual change.
                spinner.commitEdit();
                STROKE = Integer.parseInt(String.valueOf(spinner.getValue()));
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        
        return STROKE;
    }

}
