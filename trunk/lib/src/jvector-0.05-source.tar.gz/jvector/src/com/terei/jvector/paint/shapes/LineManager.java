/*
 * Created By David Terei
 * With the Eclispe IDE
 * Created on 26/04/2004
 */
package com.terei.jvector.paint.shapes;

import java.awt.Color;
import java.awt.Point;
import java.awt.geom.Point2D;
import java.awt.event.MouseEvent;
import java.util.ResourceBundle;

import javax.swing.JPanel;

import com.terei.jvector.GUI.ColorSelectedPanel;
import com.terei.jvector.GUI.options.LineOptions;


/**
 * Manages the operations for drawing a line.
 * 
 * @author David Terei
 * @since 26/04/2004
 * @version 0.4
 */
public class LineManager implements ShapeManager {
    
    /**
     * The line drawn.
     * 
     * @see Line
     */
    private Line line;
    
    /**
     * If a line is currently being drawn. 
     */
    private boolean drawing = false;

    /**
     * Returns the JPanel that holds the various options associated with a tool/shape.
     * 
     * @param rbLocale The resource bundle that holds the locale to use.
     * @return A JPanel that contains the various options associated with a shape.
     */    
    public static JPanel getOptionPanel(ResourceBundle rbLocale) {
        JPanel panel = new LineOptions(rbLocale);
        
        return panel;
    }
    
    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.ShapeManager#mousePressed(java.awt.event.MouseEvent)
     */
    public void mousePressed(MouseEvent e) {
        Point p2 = e.getPoint();
        Point2D.Double p = new Point2D.Double(p2.x,p2.y);
        if (!drawing) {
            Color color = ColorSelectedPanel.getForeColor();
            line = new Line(p,LineOptions.getStroke(),color);
            drawing = true;
        } else {
            line.setP2(p);
            drawing = false;
        }
        
    }

    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.ShapeManager#mouseReleased(java.awt.event.MouseEvent)
     */
    public void mouseReleased(MouseEvent e) {        
    }

    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.ShapeManager#mouseDragged(java.awt.event.MouseEvent)
     */
    public void mouseDragged(MouseEvent e) {        
    }

    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.ShapeManager#mouseMoved(java.awt.event.MouseEvent)
     */
    public void mouseMoved(MouseEvent e) {
        Point p2 = e.getPoint();
        Point2D.Double p = new Point2D.Double(p2.x,p2.y);
        if (drawing && line != null)
            line.setP2(p);
    }

    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.ShapeManager#getDone()
     */
    public boolean getDone() {
        return !drawing;
    }

    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.ShapeManager#getShape()
     */
    public Shape getShape() {
        return line;
    }

}
