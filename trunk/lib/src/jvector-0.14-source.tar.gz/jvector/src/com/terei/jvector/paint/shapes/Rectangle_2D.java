/*
 * Created By David Terei
 * With the Eclispe IDE
 * 
 * Created on 16/05/2004
 */
package com.terei.jvector.paint.shapes;

import java.awt.BasicStroke;
import java.awt.Graphics2D;
import java.awt.Point;
import java.io.Serializable;


/**
 * Class that provides some similar functions to a java.awt.geom.Rectangle2D,
 * but doesn't have the problem with outlines. Rectangle2D and its subclasses
 * all draw the outline of the shape, 50% on the shape fill, 50% off it. When
 * using transperency, this results in the area where there are both fill and
 * outline, thus they blend together. This is not desired, and so this class 
 * deals with that problem. 
 * 
 * @author David Terei
 * @since 15/05/2004
 * @version 0.1
 */
public class Rectangle_2D implements Serializable {
    
    /**
     * The signiture number for this class for use with serilization.
     * This number is normally generated on the fly by analyzing the
     * class and its fields. By manually specifing it, i am able to
     * change so parts of this class, while still allowing older saved
     * maps to remain compatible, as these id's must match with the saved
     * one and this class.
     */
    private static final long serialVersionUID = 973050406872567120L;
    
    /**
     * The starting point of the rectangle.
     */
    Point p;
    /**
     * The dimensions of the rectangle.
     */
    Point dim;
    /**
     * The outline stroke of the rectangle.
     */
    int stroke = 1;
    
    /**
     * The rectangle that draws the outline of the overall rectangle.
     */
    java.awt.Rectangle outline;
    /**
     * The rectangle that draws the fill of the overall rectangle.
     */
    java.awt.Rectangle fill;
    
    /**
     * Create a new rectangle.
     * 
     * @param x The starting x point of the rectangle.
     * @param y The starting y point of the rectangle.
     * @param width The width of the rectangle.
     * @param height The height of the rectangle.
     * @param stroke The width of the rectangle.
     */
    public Rectangle_2D(int x, int y, int width, int height, int stroke) {
        p = new Point(x, y);
        dim = new Point(width, height);
        this.stroke = stroke;
        calculateSizes();
    }
    
    /**
     * Calculates the sizes of the two individual rectangle's which
     * make up the overall rectangle.
     * 
     * @see Rectangle_2D#outline
     * @see Rectangle_2D#fill
     */
    protected void calculateSizes() {
        outline = new java.awt.Rectangle(p.x, p.y, dim.x, dim.y);
        fill = new java.awt.Rectangle(p.x+(int)(stroke/2+0.5), p.y+(int)(stroke/2+0.5), 
                                  dim.x-(int)(stroke+0.5), dim.y-(int)(stroke+0.5));
    }
    
    /**
     * Test to see if the rectangle contains the point specified.
     * 
     * @param p The point to test
     * @return If the point is contained within the rectangle
     */
    public boolean contain(Point p) {
        return outline.contains(p.x, p.y);
    }
    
    /**
     * Sets the stroke of the rectangle's outline.
     * 
     * @param stroke The value to set the stroke to.
     */
    public void setStroke(int stroke) {
        this.stroke = stroke;
        calculateSizes();
    }
    
    /**
     * Paints the fill of the rectangle.
     * 
     * @param g The graphics component to paint to.
     */
    public void fill(Graphics2D g) {
        g.fill(fill);
    }
    
    /**
     * Paints the outline of the rectangle.
     * 
     * @param g The graphics component to paint to.
     */    
    public void draw(Graphics2D g) {
        BasicStroke basicStroke = new BasicStroke(stroke);
        g.setStroke(basicStroke);
        g.draw(outline);
    }
    
}
