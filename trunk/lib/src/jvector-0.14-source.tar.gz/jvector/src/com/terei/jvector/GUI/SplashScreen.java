/*
 * Created By David Terei
 * With the Eclispe IDE
 * 
 * Created on 20/05/2004
 */
package com.terei.jvector.GUI;

import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JWindow;


/**
 * This class shows a splash screen, used to notify users
 * that an application has started up, but is currently loading.
 * A splash screen is a undeccorated window, that simply displays
 * am image, and is centered in the center of the screen.
 * 
 * @author David Terei
 * @since 20/05/2004
 * @version 0.1
 */
public class SplashScreen extends JWindow {
    
    /**
     * Create a new Splash Screen.
     */
    public SplashScreen(ImageIcon image) {
        JLabel label = new JLabel(image);
       
        getContentPane().add(label);

        pack();
        Dimension dim =
            Toolkit.getDefaultToolkit().getScreenSize();
        int x = (int)(dim.getWidth() - this.getWidth())/2;
        int y = (int)(dim.getHeight() - this.getHeight())/2;
        setLocation(x,y);
    }
    
}
