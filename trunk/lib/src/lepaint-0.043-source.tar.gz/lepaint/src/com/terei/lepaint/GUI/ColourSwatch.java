/*
 * Created By David Terei
 * With the Eclispe IDE
 * 
 * Created on 7/05/2004
 */
package com.terei.lepaint.GUI;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.Properties;

import javax.swing.JPanel;


/**
 * 
 * 
 * @author David Terei
 * @since 7/05/2004
 * @version 0.1
 */
public class ColourSwatch extends JPanel implements MouseListener {
    
    private static int COLUMS = 16;
    
    /**
     * Holds the resource bundle (.properties file) that contains
     * the data that this swatch displays.
     */
    private Properties rb;
    
    private List buttons;   
    
    /**
     * Create a new ColourSwatch.
     * 
     * @param bundle The path to the properties file that contains the swatch colour
     * 				 information. 
     */
    public ColourSwatch(String bundle) {
        rb = loadSwatch(bundle);
        buttons = loadButtons(rb);
        setupPanel(buttons);
        //saveProperties();
    }
    
    private Properties loadSwatch(String path) {
        Properties bundle = new Properties();
        try {            
            InputStream in = this.getClass().getClassLoader().getResourceAsStream(path);
            if (in != null) {
                bundle.load (in); // Can throw IOException
            }
            in.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return bundle;
    }
    
    private List loadButtons(Properties p) {        
        int size = Integer.parseInt(p.getProperty("Colors"));
        List l = new ArrayList(size);
        for (int i=0; i<size; i++) {
            String s = p.getProperty("Color."+(i+1));
            l.add(createColor(s));
        }
        return l;
    }
    
    private JColor createColor(String colors) {
        int[] rgb = getColors(colors);
        Color color = new Color(rgb[0], rgb[1], rgb[2]);
                
        JColor jcolor = new JColor(color);
        jcolor.addMouseListener(this);
        
        return jcolor;
    }
    
    private int[] getColors(String string) {
        int[] rgb = new int[3];
        String[] s = string.split(",");
        rgb[0] = Integer.parseInt(s[0]);
        rgb[1] = Integer.parseInt(s[1]);
        rgb[2] = Integer.parseInt(s[2]);
        //rgb[3] = Integer.parseInt(s[3]);
        
        return rgb;
    }
    
    private void setupPanel(List buts) {
        double temp = buts.size()/16;
        int rows = (int)Math.ceil(temp);
            
        GridLayout layout = new GridLayout(rows,COLUMS);
        this.setLayout(layout);
        
        for (ListIterator i = buts.listIterator(); i.hasNext(); ) {
            JColor but = (JColor)i.next();
            int x = ColorPanel.WIDTH/COLUMS;
            but.setPreferredSize(new Dimension(x,x-3));
            this.add(but);
        }
        
    }
    
    /*private void saveProperties() {
        int[] rgb = initRawValues();
        
        Properties p = new Properties();
        
        for (int i=0; i<rgb.length/3; i++) {
            p.setProperty("Color."+(i+1), String.valueOf(rgb[i*3])+","
                    					  +String.valueOf(rgb[i*3+1])+","
                    					  +String.valueOf(rgb[i*3+2]));        
        }       
        
        try {
            FileOutputStream out = new FileOutputStream("javaStandard.properties");
            p.store(out, "Test");
        } catch (Exception e) {
            
        }
    }*/

    /* (non-Javadoc)
     * @see java.awt.event.MouseListener#mouseClicked(java.awt.event.MouseEvent)
     */
    public void mouseClicked(MouseEvent e) {
        JColor jcolor = (JColor)e.getComponent();
        Color color = jcolor.getColor();
        ColorSelectedPanel.setColor(color);
    }

    /* (non-Javadoc)
     * @see java.awt.event.MouseListener#mouseEntered(java.awt.event.MouseEvent)
     */
    public void mouseEntered(MouseEvent e) {
    }

    /* (non-Javadoc)
     * @see java.awt.event.MouseListener#mouseExited(java.awt.event.MouseEvent)
     */
    public void mouseExited(MouseEvent e) {
    }

    /* (non-Javadoc)
     * @see java.awt.event.MouseListener#mousePressed(java.awt.event.MouseEvent)
     */
    public void mousePressed(MouseEvent e) {        
    }

    /* (non-Javadoc)
     * @see java.awt.event.MouseListener#mouseReleased(java.awt.event.MouseEvent)
     */
    public void mouseReleased(MouseEvent e) {        
    }
    
}
