Thankyou for your interest in Le Paint.
This file explains the process needed to build and run Le Paint.

------------
Requirnments
------------
* Java VM 1.4.2 (Probally works on lower JRE, but not tested).
* Ant 1.6.1 (Probally works on lower versions, but not tested).
            (Ant is not actually needed, but will handle the build
             process for you.)
* Assumed understanding of how to use Ant.

------------------
Build File Targets
------------------
* compile - Compiles the program, this target should be used to generate a binary version
            of Le Paint Initially.
* clean - Deletes all the files in the build (bin) directory, except those in the Resources folder.
* build - Cleans and then compiles Le Paint.
* jar - Packages Le Paint into a self executable jar archive, ("lib/LePaint.jar").
* run - Runs Le Paint.
* jar-run - Runs the jar packaged version of the program, ("lib\LePaint.jar").
* pack - Creates a compressed tar archive (tar.gz) containing the source code and documentation
         for it (lepaint-${version}-source.tar.gz).
* javadoc - Builds the JavaDoc for Le Paint, placing it in the "doc" directory.
* viewdoc - Attempts to launch Internet Explorer, and view the javadoc. (Only works on Windows).