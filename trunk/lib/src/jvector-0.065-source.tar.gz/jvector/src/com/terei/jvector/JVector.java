/*
 * Created By David Terei
 * With the Eclispe IDE
 * 
 * Created on 2/05/2004
 */
package com.terei.jvector;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Frame;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JToolBar;
import javax.swing.KeyStroke;
import javax.swing.UIManager;

import com.terei.jvector.GUI.ColorPanel;
import com.terei.jvector.GUI.NewImageDialog;
import com.terei.jvector.GUI.PaintTab;
import com.terei.jvector.GUI.PaintTabbedPane;
import com.terei.jvector.GUI.StatusBarManager;
import com.terei.jvector.language.LangLoader;
import com.terei.jvector.paint.PaintCanvas;
import com.terei.jvector.paint.shapes.LineManager;
import com.terei.jvector.paint.shapes.OvalManager;
import com.terei.jvector.paint.shapes.RectangleManager;
import com.terei.jvector.paint.shapes.ShapeManager;

/**
 * This is the main class for the JVector project. This
 * project aims to create a vector based paint program, for
 * more details, see the documentation that should have
 * accompinied this source code.
 * 
 * This class initializes the program and provides the GUI
 * frontend of the porgram.
 * 
 * @author David Terei
 * @since 19/04/2004 (dd/mm/yyyy)
 * @version 0.1
 */
public class JVector extends JFrame implements ActionListener {
	
    /**
     * Initializes the class.
     * 
     * @param args No arguments used.
     */
	public static void main(String[] args) {
	    setLookAndFeel();
	    JVector vect = new JVector();
        vect.newImage("Debug",1000,1000);        
	}
	
	/**
	 * Sets the Look and Feel of the program.
	 */
	private static void setLookAndFeel() {
	    try {
	        // NATIVE!!
	        ///*
	        boolean windows = false;	        	            
	        //Get the native look and feel class name
	        String nativeLF = UIManager.getSystemLookAndFeelClassName();	        
	        if(nativeLF.equalsIgnoreCase("com.sun.java.swing.plaf.windows.WindowsLookAndFeel"))
	            windows = true;
	        UIManager.setLookAndFeel(nativeLF);
	        
	        ///if(windows)
	        //    net.java.plaf.LookAndFeelPatchManager.initialize();
	        //*/
	        
	        
	        // JGOODIES!!
	        //UIManager.setLookAndFeel(new com.jgoodies.plaf.windows.ExtWindowsLookAndFeel());
	        //UIManager.setLookAndFeel(new com.jgoodies.plaf.plastic.PlasticLookAndFeel());
	        //UIManager.setLookAndFeel(new com.jgoodies.plaf.plastic.Plastic3DLookAndFeel());
	        //com.jgoodies.clearlook.ClearLookManager.setMode(
	        //              com.jgoodies.clearlook.ClearLookMode.DEBUG);
	        
	        
	        // ALLOY!!
	        /*
	        //This Look and Feel is a downloaded one that cost money.
            //Setup the licence information.
            com.incors.plaf.alloy.AlloyLookAndFeel.setProperty("alloy.licenseCode", "2004/05/16#ned2076@hotmail.com#1dcphtg#17m11i");
            //Set the frames to be decorated.
            com.incors.plaf.alloy.AlloyLookAndFeel.setProperty("alloy.isLookAndFeelFrameDecoration","true");
            //Set the theme to glass.
            com.incors.plaf.alloy.AlloyTheme theme = new com.incors.plaf.alloy.themes.glass.GlassTheme();
            //Set the L&F.
            UIManager.setLookAndFeel(new com.incors.plaf.alloy.AlloyLookAndFeel(theme));
            //*/
            
            
            // KUNSTOFF!!
            //UIManager.setLookAndFeel(new com.incors.plaf.kunststoff.KunststoffLookAndFeel());
	    } catch(Exception e) {
	        System.out.println("Error setting native LAF: " + e);
	    }
	}
	
	/**
	 * The path to where the tool icons are stored.
	 */
	 private static final String TOOL_PATH = "Resources/Tools/";
	
	/**
	 * The name of the locale to load.
	 */
	 private static String LOCALE = "jvector";	
	
	/**
	 * The locale file for the program.
	 * Contains all the strings for the program.
	 */
	private static ResourceBundle rbLocale;
	
	
	/**
	 * A clas which provides an easy method to implement
	 * a status bar.
	 */
	public static StatusBarManager cSbm;	
	
	/**
	 * Holds this classes content pane.
	 */
	private Container cont;
	
	/**
	 * Holds the edditing components, incluiding the tabbed
	 * canvas and toolbars.
	 */
	private JPanel jpEditor;
	
	/**
	 * Holds the help status bar at the bottom of the 
	 * application.
	 */
	private JPanel jpStatus = new JPanel();
	
	/**
	 * Holds a panel added to the extra tool bar that provides
	 * the ability to select a colour.
	 */
	private ColorPanel jpColor;
	
	/**
	 * Holds a panel added to the extra tool bar that provides
	 * some options specific to the tool currently selected.
	 */
	private JPanel jpTool = new JPanel();
	
	/**
	 * The Menu Bar.
	 */
	private JMenuBar jmbM = new JMenuBar();
	
	/**
	 * The File Menu Bar.
	 */
	private JMenu jmFile;
	
	/**
	 * The new menu item under the file menu.
	 */
	private JMenuItem jmiF_new;
	
	/**
	 * The exit menu item under the file menu.
	 */
	private JMenuItem jmiF_exit;
		
	
	/**
	 * The Tabbed Pane where the various open images are held.
	 */
	private PaintTabbedPane cPtp;	
	/**
	 * The Tool Bar that holds the drawing tools.
	 */
	private JToolBar jtbDraw;
	/**
	 * The tool bar that holds the colors and tool options.
	 */
	private JToolBar jtbO;
	
	/**
	 * A vector that holds all the PaintTab's so that various
	 * functions can be easily performed on them.
	 */
	private Vector canvases = new Vector();
		
	
	/**
	 * The help status line the appears at the bottom of
	 * the screen.
	 */
	private static JLabel jlStatus = new JLabel(" ");
    
    /**
     * Initialise the StatusBarManager class, cSbm, and load the
     * language locale resource bundle for these static variables.
     */
    static {
        try {
            rbLocale = LangLoader.getLocale(LOCALE);
            cSbm = new StatusBarManager(jlStatus);
            jlStatus.setBorder(BorderFactory.createLoweredBevelBorder());        
        } catch(Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
	
	/**
	 * Initialises the program. Calls the various methods to
	 * set up the GUI and event handlers.
	 */
	public JVector() {
	    	    	   
        jpColor = new ColorPanel();
        
	    setupFrame();
	    setupStatusBar();	    
	    setupMenu();
	    setupEditorPane();	    
	    
	    //Enable the hints status line hints for this frame.
	    cSbm.enableHints(this);
	    //show the program.
	    //show();
	    EventQueue.invokeLater(new FrameShower(this));
	}    
	
	 /**
     * A small class that takes a frame, and calls its <Code>show()</Code>
     * method, using a thread. This allows the given frame to be shown in
     * a thread safe manner by enqueing it on the event dispatch thread.
     *
     * @see <a href="http://java.sun.com/developer/JDCTechTips/2003/tt1208.html#1"> An Sun Java Article Explaining this</a>
     * 
     * @author David Terei
     * @since 22/01/2004
     * @version 1
     */
    private static class FrameShower implements Runnable {
        final Frame frame;

        /**
         * The Constructor
         */
        public FrameShower(Frame frame) {
            this.frame = frame;
        }

        /**
         * The thread, just calls the given frame <Code>show()</Code> method.
         */
        public void run() {
            frame.show();
        }
    }
    
    /**
     * A inner class that handles component events.
     * Specifically it handles the component events, of
     * the various toolbars, calling appropriate methods
     * when they are moved to resize the various windows.
     * 
     * @author David Terei
     * @since 22/04/2004
     * @version 1
     */
    private class MyComponentListener implements ComponentListener {

        /* (non-Javadoc)
         * @see java.awt.event.ComponentListener#componentHidden(java.awt.event.ComponentEvent)
         */
        public void componentHidden(ComponentEvent e) {
        }

        /* (non-Javadoc)
         * @see java.awt.event.ComponentListener#componentMoved(java.awt.event.ComponentEvent)
         */
        public void componentMoved(ComponentEvent e) {	
        }

        /* (non-Javadoc)
         * @see java.awt.event.ComponentListener#componentResized(java.awt.event.ComponentEvent)
         */
        public void componentResized(ComponentEvent e) {
            setupExtraBar();     
             
            for(int i=0;i<canvases.size(); i++) {
                PaintTab temp = (PaintTab)canvases.get(i);
                temp.resizeView(temp.SIZE_CURRENT.x, temp.SIZE_CURRENT.y,
                        		cPtp.getSize().width, cPtp.getSize().height);
            }
        }

        /* (non-Javadoc)
         * @see java.awt.event.ComponentListener#componentShown(java.awt.event.ComponentEvent)
         */
        public void componentShown(ComponentEvent e) {            
        }
        
    }
	
    /**
     * Get the resource bundle containg the current locale.
     * 
     * @return Returns the rbLocale.
     */
    public static ResourceBundle getRBLocale() {
        return rbLocale;
    }
    
	/* (non-Javadoc)
     * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
     */
    public void actionPerformed(ActionEvent e) {
        //Get the source of the object
        Object src = e.getSource();
        
        if(src.equals(jmiF_new))
            NewImageDialog.showGUI(300,200,this);
        else if(src.equals(jmiF_exit))
        	System.exit(0); //Exit if its the exit item.
    }

    /**
     * Setups The JFrame properties, such as title.
     */
    private void setupFrame() {
        setTitle(rbLocale.getString("Title"));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(0,0,700,550);
        
        //The following statement needs to be commented out
        //to work on Max OS X, as there VM doesn't include
        //this method. (Only for when trying to compile).
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        
        //set the frame icon.
        Image icon = loadImageIcon("Resources/icon.jpg").getImage();
        setIconImage(icon);        
        //set the frame layout.
        cont = getContentPane();
        cont.setLayout(new BorderLayout());
    }
    
    /**
     * Setups the status bar at the bottom of the application
     * that displays helpful hints
     */
    private void setupStatusBar() {
        jpStatus.setLayout(new BorderLayout());
        jpStatus.add(jlStatus);
        cont.add(jpStatus, BorderLayout.SOUTH);      
    }
    
    /**
     * Setups the Menu Bar
     */
    private void setupMenu() {
        // TODO make keyboard shortucts mappable
        jmFile = setupFileJM();
        jmbM.add(jmFile);
        jmbM.add(jmFile);
        this.setJMenuBar(jmbM);
    }

    /**
     * Setups the File Menu on the Menu Bar
     */
    private JMenu setupFileJM() {        
        //Create the File Menu
        JMenu jm = new JMenu(rbLocale.getString("Menu.File"));
       	
        //Create the vrious menu items
       	jmiF_new = createMenuItem("File.New");
       	jmiF_new.setAccelerator(KeyStroke.getKeyStroke(
       	        			KeyEvent.VK_N, ActionEvent.CTRL_MASK));
        jmiF_exit = createMenuItem("File.Exit");
        jmiF_exit.setAccelerator(KeyStroke.getKeyStroke(
                			KeyEvent.VK_Q, ActionEvent.CTRL_MASK));
       	
       	//Add the menu items to the File Menu
       	jm.add(jmiF_new);
       	jm.add(jmiF_exit);
       	
       	//Return the menu
        return jm;
    }
    
    /**
     * Provides an easy method to create menu items to
     * avoide repetative coding.
     */
    private JMenuItem createMenuItem(String item) {
        //Crete Menu Item and Listener
        JMenuItem jmi = new JMenuItem(
                rbLocale.getString("Menu."+item));
        jmi.addActionListener(this);
        
        //try To Get its tooltip.
        //If none exists, catch the exception, and set
        //its name as the tooltip.
        try {
            cSbm.addHintFor(jmi,
                rbLocale.getString("Menu."+item+".ToolTip"));
        } catch (MissingResourceException e) {
            cSbm.addHintFor(jmi, 
                    rbLocale.getString("Menu."+item));
        }
        
        return jmi;
    }
    
    /**
     * Setups the Editor pane, which containts the
     * drawing tabs and toolbars.
     */
    private void setupEditorPane() {
        //Setup the JPanel
        jpEditor = new JPanel(new BorderLayout());
        
        //Setups the various items on it
        setupToolBar();
	    //setupExtraBar();
        initExtraBar();
	    setupTabbedPane();
	    
	    //add it to the frame
	    cont.add(jpEditor, BorderLayout.CENTER);
    }
    
    /**
     * Setupd the toolbar where all the image drawing tools
     * are situated.
     */
    private void setupToolBar() {
        //Setup the tool bar
        jtbDraw = new JToolBar(rbLocale.getString("DrawBar.Title"),
                				JToolBar.VERTICAL);
        jtbDraw.setRollover(true);
        cSbm.addHintFor(jtbDraw,rbLocale.getString("DrawBar.ToolTip"));
        jtbDraw.setToolTipText(rbLocale.getString("DrawBar.ToolTip"));
        jtbDraw.addComponentListener(new MyComponentListener());
        
        //Create and Add the tools
        JButton jb_line = createTool("line.png", 
        			rbLocale.getString("DrawBar.Line.Tip"),PaintCanvas.TOOL_LINE);
        jtbDraw.add(jb_line);
        
        JButton jb_rect = createTool("rectangle.png",
                	rbLocale.getString("DrawBar.Rectangle.Tip"),PaintCanvas.TOOL_RECT);
        jtbDraw.add(jb_rect);
        
        JButton jb_oval = createTool("oval.png",
                rbLocale.getString("DrawBar.Rectangle.Tip"),PaintCanvas.TOOL_OVAL);
        jtbDraw.add(jb_oval);
        
        //add the toolbar in
        jpEditor.add(jtbDraw, BorderLayout.WEST);
        
    } 
    
    /**
     * Creates a Tool with the paramaters specified.
     *
     * @param icon_name The Icon for the Tool.
     * @param ToolTip The mouse over ToolTip for the tool (appears in status bar).
     * @param tool Which tool this tool is.
     */
    private JButton createTool(String icon_name, String ToolTip,
                                                    int tool) {
        //get the image icon.
        ImageIcon icon = loadImageIcon(TOOL_PATH + icon_name);
        //create the new button with the icon.
        JButton button = new JButton(icon);
        //set the status bar tip for it.
        cSbm.addHintFor(button,ToolTip);
        //set the sizes of it.
        button.setPreferredSize(new Dimension(36,36));
        button.setMaximumSize(new Dimension(48,48));
        button.setMinimumSize(new Dimension(24,24));
        //add an action listener to it.
        button.addActionListener(createToolListener(tool));
        
        return button;
    }
    
    /**
     * Creates an Action listener for a tool button, that
     * notifies the MapInterface class of a tool change.
     *
     * @see com.terei.jvector.GUI.PaintTab#setTool
     */
    private ActionListener createToolListener(int selected) {
        //because of the way this is done, a final int must be used
        //within the action listener, so that it cant change.
        final int tool = selected;
        //create a new action listener and return it.
        return (new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                PaintTab.setTool(tool);
                setupExtraBar();
            }
        });
    }
    
    /**
     * Initialises the extra tool bar. This method needs to be called
     * only once at the start, after that, <code>setupExtraBar()</code>
     * should be called.
     */
    private void initExtraBar() {
        jtbO = new JToolBar(rbLocale.getString("ExtraBar.Title"),
				JToolBar.VERTICAL);
        //cSbm.addHintFor(jtbO,rbLocale.getString("ExtraBar.ToolTip"));
        jtbO.addComponentListener(new MyComponentListener());            
        
        setupExtraBar();
        
        jpEditor.add(jtbO, BorderLayout.EAST);
    }
    
    /**
     * Setups the extra tool bar which contains the colour chooser and 
     * the tool options bar. This method should be called every time
     * the Extra Bar is modified.
     */
    private void setupExtraBar() {
        
        //get the tool bars orientation.
        int orit = jtbO.getOrientation();
        
        //the tool bar already exist, so remove everything.
   	    jtbO.removeAll();
       	    
       	//add a rigid component to the tool bar, so that it doesnt push right
   	    //against the panel added to it. The dimensions of the rigid area depend
   	    //on the orientation of the tool bar.
        if(orit==JToolBar.VERTICAL)
            jtbO.add(Box.createRigidArea(new Dimension(ColorPanel.WIDTH+20,2)));
        else
            jtbO.add(Box.createRigidArea(new Dimension(5,2)));
        
        //Add the tools back in
        jtbO.add(jpColor);        
        jpTool = getToolOptionBar();
		jtbO.add(jpTool);
		
		//tell it to 'refresh' itself.
		jtbO.revalidate();        
    }
    
    /**
     * Creates the jpanel to add to the extra tool bar
     * which contains the various options for the currently
     * selected tool.
     * 
     * @see com.terei.jvector.paint.shapes.ShapeManager
     */
    protected JPanel getToolOptionBar() {
        //get the currently selected tool.
        int TOOL = PaintCanvas.getTool();
        
        //new jpanel that will hold the tools option jpanel.
        JPanel panel = ShapeManager.getOptionPanel();        
        
        //Get the option panel for the currently selected tool.
        switch(TOOL) {
      		case PaintCanvas.TOOL_NULL: ; break;
      		case PaintCanvas.TOOL_LINE: 
      			panel = LineManager.getOptionPanel(); break;
      		case PaintCanvas.TOOL_RECT: 
      			panel = RectangleManager.getOptionPanel(); break;
            case PaintCanvas.TOOL_OVAL: 
                panel = OvalManager.getOptionPanel(); break;
        }
        
        return panel;        
    }

    /**
     * seups the tabbed pane which holds all the open
     * images currently being worked on.
     */
    private void setupTabbedPane() {
        cPtp = new PaintTabbedPane();
        cPtp.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);
        jpEditor.add(cPtp,BorderLayout.CENTER);
    }
    
    /**
	 * Loads an image icon in a way that allows
	 * for the application to be stored in a rar
	 * or nativley compiled, as well as run as
	 * just plain class files.
	 *
	 * @param path The path, relative to the working directory, to the image.
	 */
    public static ImageIcon loadImageIcon(String path) {
        URL url = JVector.class.getClassLoader().getResource(path);
        return (new ImageIcon(url));
    }
    
    /**
     * Creates a new Image/Canvas.
     * 
     * @param name The name of the image
     * @param x The width of the image
     * @param y The height of the image
     */
    public void newImage(String name, int x, int y) {
        Dimension d_jtp = cPtp.getSize();
        PaintTab can = new PaintTab(name,x,y,d_jtp.width,d_jtp.height);
        String tooltip = "Change to this Image: "+name;
        cPtp.addTab(name,null,can,tooltip);
        canvases.add(can);    
    }

}
