package edu.stanford.ejalbert.launching.macos;

import java.lang.reflect.Constructor;

import edu.stanford.ejalbert.BrowserLauncher;
import edu.stanford.ejalbert.exception.BrowserLaunchingExecutionException;
import edu.stanford.ejalbert.exception.BrowserLaunchingInitializingException;
import edu.stanford.ejalbert.launching.IBrowserLaunching;

/**
 * @author Markus Gebhard
 */
public class MacOs3_0BrowserLaunching implements IBrowserLaunching {

  public void initialize() throws BrowserLaunchingInitializingException {
    try {
      Class linker = Class.forName("com.apple.mrj.jdirect.Linker");
      Constructor constructor = linker.getConstructor(new Class[] { Class.class });
      Object linkage = constructor.newInstance(new Object[] { BrowserLauncher.class });
    }
    catch (Exception e) {
      throw new BrowserLaunchingInitializingException(e);
    }
  }

  public void openUrl(String urlString) throws BrowserLaunchingExecutionException {
    int[] instance = new int[1];
    int result = ICStart(instance, 0);
    if (result == 0) {
      int[] selectionStart = new int[] { 0 };
      byte[] urlBytes = urlString.getBytes();
      int[] selectionEnd = new int[] { urlBytes.length };
      result =
        ICLaunchURL(instance[0], new byte[] { 0 }, urlBytes, urlBytes.length, selectionStart, selectionEnd);
      if (result == 0) {
        // Ignore the return value; the URL was launched successfully
        // regardless of what happens here.
        ICStop(instance);
      }
      else {
        throw new BrowserLaunchingExecutionException("Unable to launch URL: " + result);
      }
    }
    else {
      throw new BrowserLaunchingExecutionException("Unable to create an Internet Config instance: " + result);
    }
  }

  /**
   * Methods required for Mac OS X.  The presence of native methods does not cause
   * any problems on other platforms.
   * 
   * @param instance
   * @param signature 
   * @return
   */
  private native static int ICStart(int[] instance, int signature);
  private native static int ICStop(int[] instance);
  private native static int ICLaunchURL(
    int instance,
    byte[] hint,
    byte[] data,
    int len,
    int[] selectionStart,
    int[] selectionEnd);
}