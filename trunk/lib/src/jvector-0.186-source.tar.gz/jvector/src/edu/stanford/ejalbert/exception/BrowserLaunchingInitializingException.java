package edu.stanford.ejalbert.exception;


/**
 * @author Markus Gebhard
 */
public class BrowserLaunchingInitializingException extends BrowserLaunchingExecutionException {

  public BrowserLaunchingInitializingException(Exception cause) {
    super(cause);
  }

  public BrowserLaunchingInitializingException(String message) {
    super(message);
  }

}