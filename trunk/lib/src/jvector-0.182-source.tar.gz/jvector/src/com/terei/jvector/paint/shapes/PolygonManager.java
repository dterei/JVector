/*
 * Created By David Terei
 * With the Eclispe IDE
 * 
 * Created on 16/05/2004
 */
package com.terei.jvector.paint.shapes;

import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;

import javax.swing.JPanel;

import com.terei.jvector.GUI.ColorSelectedPanel;
import com.terei.jvector.GUI.options.RectangleOptions;


/**
 * Manages the operations for drawing a polygon.
 * 
 * @author David Terei
 * @since 16/05/2004
 * @version 1
 */
public class PolygonManager extends ShapeManager implements Runnable {
    
    /**
     * The maximum time in milliseconds between two clicks
     * for it to be registered as a double click.
     * 
     * @see #time
     * @see #run()
     */
    private static final int DOUBLE_SPEED = 200;
    
    /**
     * Holds the Polygon this class works with.
     */
    protected Polygon poly;
    
    /**
     * Holds the amount of time between mouse clicks, used to test for double clicks.
     * 
     * @see #DOUBLE_SPEED
     * @see #run()
     */
    private long time = DOUBLE_SPEED;
    
    /**
     * Holds a reference point for a polygon, used to move it.
     */
    private Point p = new Point();
    
    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.ShapeManager#getOptionPanel()
     */
    public static JPanel getOptionPanel() {        
        return new RectangleOptions();
    }
    
    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.ShapeManager#mousePressed(java.awt.event.MouseEvent)
     */
    public void mousePressed(MouseEvent e, int zoomLevel) { 
        Point2D.Double p = new Point2D.Double(e.getPoint().x, e.getPoint().y);
        p.x /= ((double)zoomLevel/100);
        p.y /= ((double)zoomLevel/100);
        
        //test to see if a polygon is currently being drawn or not.
        if (super.MODE == super.MODE_IDLE) {
            
            super.MODE = super.MODE_DRAW;            
            
            //no, one isnt being draw, so create a new one.
            poly = new Polygon(p, RectangleOptions.getStroke());            
            poly.setFillColor(ColorSelectedPanel.getBackColor());
            poly.setFillOpacity(ColorSelectedPanel.getBackOpacity());
            poly.setOutlineColor(ColorSelectedPanel.getForeColor());
            poly.setOutlineOpacity(ColorSelectedPanel.getForeOpacity());
            //add a second point, for the one displayed when moving the mouse.
            poly.addPoint(p);
            poly.resize(((double)zoomLevel/100));
            
        } else if (super.MODE == super.MODE_DRAW) {
            
            //polygon currently being draw, so lets add a point or finish it.
            //test for a double click.
            if (time<DOUBLE_SPEED) {
                //delete the last point, as it is an extra point serving
                //as a visual guide when moving the mouse.
                poly.deletePoint(poly.getLength()-1);
                //make sure there are at least 3 points (triangle)
                //if there are not, delete the shape.
                if (poly.getLength()<3) {
                    poly = null;
                }

                super.MODE = super.MODE_IDLE;               
                return;
            }
            
            //reset the double click time.
            time = 0;
            //start the counting thread again.
            Thread thread = new Thread(this);
            thread.start();            
            //add a new point to the polygon.
            poly.addPoint(p);
            poly.resize(((double)zoomLevel/100));
            
        }
    }

    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.ShapeManager#mouseMoved(java.awt.event.MouseEvent)
     */
    public void mouseMoved(MouseEvent e, int zoomLevel) {
        if (super.MODE == super.MODE_DRAW) {
            Point2D.Double p = new Point2D.Double(e.getPoint().x, e.getPoint().y);
            p.x /= ((double)zoomLevel/100);
            p.y /= ((double)zoomLevel/100);
            
            poly.setPoint(p, poly.getLength()-1);
            poly.resize(((double)zoomLevel/100));
        }
    }
    
    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.ShapeManager#getShape()
     */
    public Shape getShape() {
        return poly;
    }

    /**
     * Serves as a simple timing thread, used to test for double clicks.
     */
    public void run() {
        while(time<DOUBLE_SPEED) {
            try {
                Thread.sleep(1);
                time++;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.ShapeManager#moveShape(com.terei.jvector.paint.shapes.Shape, java.awt.event.MouseEvent)
     */
    public boolean moveShape(Shape shape, MouseEvent e, int zoomLevel) {
        //get the point of where this mouse event occured.
        Point pe = e.getPoint();
        //convert it to the correct 100% zoom values.         
        pe.x /= ((double)zoomLevel/100);
        pe.y /= ((double)zoomLevel/100);
        
        //try to cast the shape to a Rectangle shape, catching an error
        //that may occur is the shape isnt a Rectangle shape.
        Polygon pTemp;
        try {
            pTemp = (Polygon)shape;
        } catch (ClassCastException exc) {
            //it wasnt a Rectangle shape, so print out a stacktrace for debugging
            exc.printStackTrace();
            //and return false
            return false;
        }
        
        //A drag operation works by, finding the distance between the shapes
        //refernce point, and the mouse, as this shouldnt change when moving
        //the shape. So once we have that distance, we just move the shapes
        //reference point, keeping it the same distance from the mouse.
        if (super.MODE == super.MODE_IDLE) {           
            p = new Point(pe.x, pe.y);
            super.MODE = super.MODE_MOVE;
        } else { 
            int x = pe.x - p.x;
            int y = pe.y - p.y;   
            pTemp.translate(x,y);            
            p = new Point(pe.x, pe.y);
            pTemp.resize(((double)zoomLevel/100));
        }
                
        return true;
    }

}
