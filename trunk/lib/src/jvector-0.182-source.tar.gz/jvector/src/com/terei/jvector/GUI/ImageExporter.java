/*
 * Created By David Terei
 * With the Eclispe IDE
 * 
 * Created on 2/06/2004
 */
package com.terei.jvector.GUI;

import java.io.File;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;

import com.terei.jvector.JVector;
import com.terei.jvector.paint.ImageFile;
import com.terei.jvector.plugin.ImagePlugin;
import com.terei.jvector.plugin.ImagePluginManager;


/**
 * This class manages the exporting of JVector images to various
 * other formats, which are availible as plugins. It also provides
 * the GUI for the user to do this. 
 * 
 * @author David Terei
 * @version 1
 * @since 2/06/2004
 * 
 * @see com.terei.jvector.plugin.ImagePluginManager
 * @see com.terei.jvector.plugin.ImagePlugin
 */
public class ImageExporter {
    
    /**
     * The plugin manager used to get the availible plugins and access them.
     */
    private static ImagePluginManager ipm = new ImagePluginManager();
    /**
     * The file chooser dialog used to select the plugin and path to save to.
     */
    private static JFileChooser chooser = new JFileChooser();
    
    /**
     * Static Initialization block that sets up the JFileChooser used to export
     * images, so that it doesnt need to be done every time the static export method
     * is accessed.
     */
    static {
        ResourceBundle locale = JVector.getRBLocale();
        chooser.setDialogType(JFileChooser.SAVE_DIALOG);
        chooser.setAcceptAllFileFilterUsed(false);  
        
        try {
            chooser.setDialogTitle(locale.getString("Dialog.Export.Title"));
        } catch (MissingResourceException e) {
            System.err.println("Missing locale string for Save dialog" + e);
        }    
        
        try {
            FileFilter[] filters = ipm.getImageTypes();
            for (int i=0; i<filters.length; i++) {
                chooser.setFileFilter(filters[i]);
            }
            chooser.setFileFilter(filters[0]);
        } catch (Exception e) {
            e.printStackTrace();
            //TODO error box.
        }
    }
    
    /**
     * Don't allow the class to be initialized.
     */
    private ImageExporter() { 
        
    }
    
    /**
     * Exports the image specified to a format and path specified by the user.
     * This method shows a JFileChooser dialog box, listing the availible image
     * outputs, and allows tehm to choose one and export it to the path chossen.
     * 
     * @param image The image to export.
     * @param defaultDir The starting directory to show for the JFileChooser, the proveious
     * save locatio of the image is normally used.
     */
    public static void export(ImageFile image, File defaultDir) {                
        chooser.setSelectedFile(defaultDir);              
        
        int returnVal = chooser.showSaveDialog(null);
        
        if(returnVal != JFileChooser.APPROVE_OPTION)
            return;
        
        String ext = null;
        if (chooser.getFileFilter() instanceof SwingFileFilter) {
            SwingFileFilter filter = (SwingFileFilter)chooser.getFileFilter();
            ext = filter.getAcceptExtension();
            if (ext == null)
                //TODO Error logging.
                return;
        }
        
        try {
            ImagePlugin plugin = ipm.getPlugin(ext);        
        
		    File file = chooser.getSelectedFile();
		    
		    String name = file.getName();
		    
		    if (!name.endsWith("." + plugin.getExtension())) {
		        String path = file.getAbsolutePath() + "." + plugin.getExtension();
		        file = new File(path);
		    }
		    
		    plugin.save(image, file);
        } catch (NullPointerException e) {
            e.printStackTrace();
        }
    }

}
