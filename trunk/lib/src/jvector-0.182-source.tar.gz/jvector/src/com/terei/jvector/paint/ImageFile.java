/*
 * Created By David Terei
 * With the Eclispe IDE
 * 
 * Created on 16/05/2004
 */
package com.terei.jvector.paint;

import java.io.Serializable;

import com.terei.jvector.paint.shapes.Shape;


/**
 * This class provides the ability to save an image to JVector's native
 * format, which allows the image to be reopen, and worked on again.
 * 
 * This class stores all the information about an image, and it implements
 * the Serializable interface, so that it can be saved to a file through an
 * object output stream.
 * 
 * @author David Terei
 * @since 16/05/2004
 * @version 0.1
 */
public class ImageFile implements Serializable {

    /**
     * The signiture number for this class for use with serilization.
     * This number is normally generated on the fly by analyzing the
     * class and its fields. By manually specifing it, i am able to
     * change so parts of this class, while still allowing older saved
     * maps to remain compatible, as these id's must match with the saved
     * one and this class.
     */
    private static final long serialVersionUID = 843402619281875150L;
    
    /**
     * The name of the map.
     */
    public String name;    
    /**
     * The width of the map.
     */
    public int width;
    /**
     * The height of the map.
     */
    public int height;
    
    /**
     * Holds all the shapes in this image.
     * 
     * @serial
     */
    public Shape[] shapes;
    
    /**
     * Create a new ImageFile.
     * 
     * @param name The name of the image.
     * @param width The width of the image.
     * @param height The height of the image.
     * @param shapes The shapes contained in the image.
     */
    public ImageFile(String name, int width, int height, Shape[] shapes) {
        this.name = name;
        this.width = width;
        this.height = height;
        this.shapes = shapes;
    }

}
