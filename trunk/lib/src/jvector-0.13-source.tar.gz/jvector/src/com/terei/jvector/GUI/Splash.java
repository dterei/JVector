/*
 * Created By David Terei
 * With the Eclispe IDE
 * 
 * Created on 20/05/2004
 */
package com.terei.jvector.GUI;

import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;

import com.terei.jvector.JVector;


/**
 * This class shows a splash screen, used to notify users
 * that an application has started up, but is currently loading.
 * 
 * @author David Terei
 * @since 20/05/2004
 * @version 0.1
 */
public class Splash extends JPanel {

    /**
     * The frame that will display this splash screen.
     */
    private JFrame frame;
    
    /**
     * The size of the splash screen.
     */
    private Dimension size = new Dimension(400,300);
    
    /**
     * The image to draw, the actual splash you see.
     */
    private Image splash;
    
    /**
     * Create a new Splash screen.
     */
    public Splash() {        
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();         
        int x = (screenSize.width - size.width)/2;
        int y = (screenSize.height - size.height)/2;
        
        frame = new JFrame(JVector.getRBLocale().getString("Title"));        
        frame.setBounds(x, y, size.width, size.height);
        frame.setUndecorated(true);
        frame.setResizable(false);
        frame.getContentPane().add(this);
        
        splash = JVector.loadImageIcon("Resources/splash.jpg").getImage();
        
        EventQueue.invokeLater(new FrameShower(frame));
    }
    
    /**
     * A small class that takes a frame, and calls its <Code>show()</Code>
     * method, using a thread. This allows the given frame to be shown in
     * a thread safe manner by enqueing it on the event dispatch thread.
     *
     * @see <a href="http://java.sun.com/developer/JDCTechTips/2003/tt1208.html#1"> An Sun Java Article Explaining this</a>
     * 
     * @author David Terei
     * @since 22/01/2004
     * @version 1
     */
    private static class FrameShower implements Runnable {
        
        /**
         * The frame to show.
         */
        final Frame frame;

        /**
         * Constuct a new FrameShower.
         * 
         * @param frame The frame to show.
         */
        public FrameShower(Frame frame) {
            this.frame = frame;
        }

        /**
         * The thread, just calls the given frame <Code>show()</Code> method.
         */
        public void run() {
            frame.show();
        }
    }

    /* (non-Javadoc)
     * @see javax.swing.JComponent#paintComponent(java.awt.Graphics)
     */
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(splash, 0, 0, null);
    }
    
    /**
     * Closes the splash screen, and releases its resoureces.
     *
     */
    public void close() {
        frame.hide();
        frame.dispose();
        frame = null;
    }
}
