package edu.stanford.ejalbert.launching.windows;

/**
 * @author Markus Gebhard
 */
public class WindowsNtBrowserLaunching extends DefaultWindowsBrowserLaunching {
  public WindowsNtBrowserLaunching() {
    super("cmd.exe");
  }
}
