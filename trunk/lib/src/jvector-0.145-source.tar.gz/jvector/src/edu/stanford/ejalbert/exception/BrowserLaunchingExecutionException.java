package edu.stanford.ejalbert.exception;


/**
 * @author Markus Gebhard
 */
public class BrowserLaunchingExecutionException extends UnsupportedOperatingSystemException {

  public BrowserLaunchingExecutionException(Throwable cause) {
    super(cause);
  }

  public BrowserLaunchingExecutionException(String message) {
    super(message);
  }

}
