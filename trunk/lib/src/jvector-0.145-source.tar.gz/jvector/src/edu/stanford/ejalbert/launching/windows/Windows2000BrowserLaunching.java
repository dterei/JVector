package edu.stanford.ejalbert.launching.windows;

import edu.stanford.ejalbert.exception.BrowserLaunchingExecutionException;


/**
 * @author Markus Gebhard
 */
public class Windows2000BrowserLaunching extends WindowsBrowserLaunching {
  public void openUrl(String urlString) throws BrowserLaunchingExecutionException {
    try {
      // Add quotes around the URL to allow ampersands and other special
      // characters to work.
      Process process = Runtime.getRuntime().exec(new String[] { "cmd.exe", "/c", "start", urlString });
      // This avoids a memory leak on some versions of Java on Windows.
      // That's hinted at in <http://developer.java.sun.com/developer/qow/archive/68/>.
      process.waitFor();
      process.exitValue();
    }
    catch (Exception e) {
      throw new BrowserLaunchingExecutionException(e);
    }
  }
}