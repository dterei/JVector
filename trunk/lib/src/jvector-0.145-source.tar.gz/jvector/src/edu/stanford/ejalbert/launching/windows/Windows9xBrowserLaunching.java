package edu.stanford.ejalbert.launching.windows;

/**
 * @author Markus Gebhard
 */
public class Windows9xBrowserLaunching extends DefaultWindowsBrowserLaunching {
  public Windows9xBrowserLaunching(){
    super("command.com");
  }
}