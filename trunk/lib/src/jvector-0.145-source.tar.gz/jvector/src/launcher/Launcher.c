#include <unistd.h> 

main(int argc, char *argv[]) { 
    
    if(argc > 2) {
        printf("\n JVector Launcher\n");
    	printf("\n   Usage: Launcher [file]\n");
    	printf("   file - [optional] The file to open at startup\n");
    	exit(1);
    }
    
    char *arg = '"'+argv[1]+'"';
    
    execlp("java.exe", "java.exe", "-cp", "JVector.jar", 
           "com.terei.jvector.JVector", arg, null);
           
} 
