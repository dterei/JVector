/*
 * Created By David Terei
 * With the Eclispe IDE
 * Created on 26/04/2004
 */
package com.terei.jvector.paint.shapes;

import java.awt.event.MouseEvent;
import java.util.ResourceBundle;

import javax.swing.JPanel;


/**
 * Provides an interface to use for managers
 * of the various shapes. These classes handle all
 * the various operations associated with drawing
 * their shapes.
 * 
 * @author David Terei
 * @since 26/04/2004
 * @version 0.4
 */
public abstract class ShapeManager {
        
    /* (non-Javadoc)
     * @see java.awt.event.MouseListener#mousePressed(java.awt.event.MouseEvent)
     */
    public void mousePressed(MouseEvent e) {
        
    }

    /* (non-Javadoc)
     * @see java.awt.event.MouseListener#mouseReleased(java.awt.event.MouseEvent)
     */
    public void mouseReleased(MouseEvent e) {
        
    }

    /* (non-Javadoc)
     * @see java.awt.event.MouseMotionListener#mouseDragged(java.awt.event.MouseEvent)
     */
    public void mouseDragged(MouseEvent e) {
        
    }

    /* (non-Javadoc)
     * @see java.awt.event.MouseMotionListener#mouseMoved(java.awt.event.MouseEvent)
     */
    public void mouseMoved(MouseEvent e) {
        
    }
    
    /**
	 * Returns if the shape is complete, and a new shape
	 * ready to be drawn.
	 *
	 * @return If the shape is done.
	 */
   	public abstract boolean getDone();
    
    /**
	 * @return The shape being built, or done.
	 */
    public abstract Shape getShape();
    
    
    /**
     * Returns the JPanel that holds the various options associated with a tool/shape.
     * 
     * @param rbLocale The resource bundle that holds the locale to use.
     * @return A JPanel that contains the various options associated with a shape.
     */    
    public static JPanel getOptionPanel(ResourceBundle rbLocale) {
        return new JPanel();
    }
    
}
