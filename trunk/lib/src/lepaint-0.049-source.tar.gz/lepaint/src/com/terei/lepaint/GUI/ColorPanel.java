// TODO setup the colour toolbar
/*
 * Created By David Terei
 * With the Eclispe IDE
 * 
 * Created on 7/05/2004
 */
package com.terei.lepaint.GUI;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.util.ResourceBundle;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

import com.terei.lepaint.LePaint;


/**
 * Creates a panel that allows the user to set a foreground and background 
 * colour using swatches (<code>com.terei.lepaint.GUI.ColourSwatch</code>)
 * and some tools to manipulate these swatches. 
 * 
 * @author David Terei
 * @since 7/05/2004
 * @version 0.1
 */
public class ColorPanel extends JPanel {
    
    public static int WIDTH = 200;
    public static int HEIGHT = 260;
    
    private ResourceBundle rbLocale;
    
    private JButton jbAddSwatch;
    private JButton jbRemSwatch;
    private JButton jbInfSwatch;
    
    private JTabbedPane jtpSwatch;
    
    /**
     * Create a new ColourPanel.
     * 
     * @param bundle The resource bundle to use for the strings/locale of this panel.
     */
    public ColorPanel(ResourceBundle bundle) {
        super(new BorderLayout(), true);
        rbLocale = bundle;
        initGUI();
        jtpSwatch.add(new ColourSwatch("Resources/Swatches/javaStandard.properties"));
        jtpSwatch.add(new ColourSwatch("Resources/Swatches/standard.properties"));        
    }
    
    
    /**
     * Initialises the GUI.
     */
    private void initGUI() {
        jbAddSwatch = createButton("Resources/new.png", 
                		rbLocale.getString("ColorPanel.AddSwatch"));
        jbRemSwatch = createButton("Resources/bin.png", 
    						rbLocale.getString("ColorPanel.RemSwatch"));
        jbInfSwatch = createButton("Resources/info.png", 
        					rbLocale.getString("ColorPanel.InfSwatch"));
        
        JPanel jpTop = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 7));
        jpTop.add(jbAddSwatch);
        jpTop.add(jbRemSwatch);
        jpTop.add(jbInfSwatch);
        
        jtpSwatch = new JTabbedPane();
        
        JPanel jpMid = new JPanel(new BorderLayout());
        jpMid.add(jtpSwatch);
        
        JPanel jpBot = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 7));
        jpBot.add(new ColorSelectedPanel());        
        
        this.setMaximumSize(new Dimension(WIDTH,HEIGHT));
        this.add(jpTop,BorderLayout.NORTH);
        this.add(jpMid,BorderLayout.CENTER);
        this.add(jpBot,BorderLayout.SOUTH);
    }
    
    private JButton createButton(String icon, String tooltip) {
        JButton button = new JButton(LePaint.loadImageIcon(icon));
        //TODO the tooltips
        button.setToolTipText(tooltip);
        button.setPreferredSize(new Dimension(20,20));
        button.setContentAreaFilled(false);
        
        return button;
        
    }   
  
}