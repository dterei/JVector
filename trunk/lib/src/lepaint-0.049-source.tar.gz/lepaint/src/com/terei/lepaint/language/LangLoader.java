/*
 * Created on 20/04/2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package com.terei.lepaint.language;

import java.util.*;

/**
* This class provides one easy static method to load the
* currently set language file for the program specified.
*
* @author David Terei
* @since 26/12/03
* @version 1
*/
public class LangLoader {

  /**
   * Dont Allow Contrsuction
   */
  private LangLoader() {
  }

  /**
   * Loads the language bundle specified, looking in
   * the languages program, relative to the program root.
   * The locale to load is specified in the lang.properties
   * file in the prgoram root\class path.
   * For example,
   *
   * <p><Center><Dir>%PROGRAM_CLASSPATH%\Languages\%bundle%</Dir></Center>
   * This is the path of the file it will atempt to load.</p>
   *
   * @param bundle the resurce bundle to load.
   *          %PROGRAM_CLASSPATH\Languages\%bundle%
   * @return The resource bundle requested in the locale
   *      specified in the %PROGRAM_CLASSPATH\lang.properties
   *      file.
   */
  public static ResourceBundle getLocale(String bundle) {
      //Load the properties file, lang.
      ResourceBundle defLang = ResourceBundle.getBundle("lang");
      //Setup some strings to hold the Locale data.
      String LangCode = "";
      String ConCode = "";
      try {
          //Get the locale Langauge code.
          LangCode = defLang.getString("Language.Code");
          //Get the Locale Country code.
          ConCode = defLang.getString("Country.Code");
      } catch (MissingResourceException e) {
          //Catch any exceptions.
          System.err.println("getCurrentLanguage: MissingResourceException: "
                                  + e.getMessage());
      }
      //get the current langauge Locale data.
      ResourceBundle ret = ResourceBundle.getBundle("Languages."+bundle,new Locale(LangCode,ConCode));

      return ret;
  }

}