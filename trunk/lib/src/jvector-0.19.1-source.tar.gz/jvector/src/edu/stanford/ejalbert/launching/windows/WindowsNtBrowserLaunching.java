package edu.stanford.ejalbert.launching.windows;

import edu.stanford.ejalbert.exception.BrowserLaunchingExecutionException;

/**
 * @author Markus Gebhard
 */
public class WindowsNtBrowserLaunching extends DefaultWindowsBrowserLaunching {
  public WindowsNtBrowserLaunching() {
    super("cmd.exe");
  }
  
  public void openUrl(String urlString) throws BrowserLaunchingExecutionException {
    try {
      Process process =
        Runtime.getRuntime().exec(
          new String[] {
            super.browser,
            super.FIRST_WINDOWS_PARAMETER,
            super.SECOND_WINDOWS_PARAMETER,
            super.THIRD_WINDOWS_PARAMETER,
            urlString});
      // This avoids a memory leak on some versions of Java on Windows.
      // That's hinted at in <http://developer.java.sun.com/developer/qow/archive/68/>.
      process.waitFor();
      process.exitValue();
    }
    catch (Exception e) {
      throw new BrowserLaunchingExecutionException(e);
    }
  }
}
