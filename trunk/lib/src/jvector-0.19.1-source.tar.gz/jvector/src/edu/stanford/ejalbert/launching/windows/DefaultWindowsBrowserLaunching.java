package edu.stanford.ejalbert.launching.windows;

import edu.stanford.ejalbert.exception.BrowserLaunchingExecutionException;

/**
 * @author Markus Gebhard
 */
public abstract class DefaultWindowsBrowserLaunching extends WindowsBrowserLaunching {

  protected String browser;

  protected DefaultWindowsBrowserLaunching(String browser) {
    this.browser = browser;
  }

  /**
   * The first parameter that needs to be passed into Runtime.exec() to open the default web
   * browser on Windows.
   */
  protected static final String FIRST_WINDOWS_PARAMETER = "/c";

  /** The second parameter for Runtime.exec() on Windows. */
  protected static final String SECOND_WINDOWS_PARAMETER = "start";

  /**
   * The third parameter for Runtime.exec() on Windows.  This is a "title"
   * parameter that the command line expects.  Setting this parameter allows
   * URLs containing spaces to work.
   */
  protected static final String THIRD_WINDOWS_PARAMETER = ""; //"\"\"";

  public void openUrl(String urlString) throws BrowserLaunchingExecutionException {
    try {
      Process process =
        Runtime.getRuntime().exec(
          new String[] {
            browser,
            FIRST_WINDOWS_PARAMETER,
            SECOND_WINDOWS_PARAMETER,
            THIRD_WINDOWS_PARAMETER,
            '"' + urlString + '"' });
      // This avoids a memory leak on some versions of Java on Windows.
      // That's hinted at in <http://developer.java.sun.com/developer/qow/archive/68/>.
      process.waitFor();
      process.exitValue();
    }
    catch (Exception e) {
      throw new BrowserLaunchingExecutionException(e);
    }
  }
}