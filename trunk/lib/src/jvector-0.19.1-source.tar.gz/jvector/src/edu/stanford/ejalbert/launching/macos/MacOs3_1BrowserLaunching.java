package edu.stanford.ejalbert.launching.macos;

import java.lang.reflect.Method;

import edu.stanford.ejalbert.exception.BrowserLaunchingExecutionException;
import edu.stanford.ejalbert.exception.BrowserLaunchingInitializingException;
import edu.stanford.ejalbert.launching.IBrowserLaunching;

/**
 * @author Markus Gebhard
 */
public class MacOs3_1BrowserLaunching implements IBrowserLaunching {
  private Method openURL;

  public void initialize() throws BrowserLaunchingInitializingException {
    try {
      Class mrjFileUtilsClass = Class.forName("com.apple.mrj.MRJFileUtils");
      openURL = mrjFileUtilsClass.getDeclaredMethod("openURL", new Class[] { String.class });
    }
    catch (Exception e) {
      throw new BrowserLaunchingInitializingException(e);
    }
  }

  public void openUrl(String urlString) throws BrowserLaunchingExecutionException {
    try {
      openURL.invoke(null, new Object[] { urlString });
    }
    catch (Exception e) {
      throw new BrowserLaunchingExecutionException(e);
    }
  }
}