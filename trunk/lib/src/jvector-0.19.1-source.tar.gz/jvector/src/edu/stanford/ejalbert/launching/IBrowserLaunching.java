package edu.stanford.ejalbert.launching;

import edu.stanford.ejalbert.exception.BrowserLaunchingExecutionException;
import edu.stanford.ejalbert.exception.BrowserLaunchingInitializingException;


/**
 * @author Markus Gebhard
 */
public interface IBrowserLaunching {
  public void initialize() throws BrowserLaunchingInitializingException;

  public void openUrl(String urlString) throws BrowserLaunchingExecutionException ;
}