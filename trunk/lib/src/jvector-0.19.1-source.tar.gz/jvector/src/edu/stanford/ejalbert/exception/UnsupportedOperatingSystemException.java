package edu.stanford.ejalbert.exception;

/**
 * @author Markus Gebhard
 */
public class UnsupportedOperatingSystemException extends Exception {

  public UnsupportedOperatingSystemException(String message) {
    super(message);
  }

  public UnsupportedOperatingSystemException(Throwable cause) {
    super(cause);
  }

}
