#include <unistd.h> 

main(int argc, char *argv[]) {
    
    execlp("java.exe", "java.exe", "-jar", "JVector.jar", 0);
           
} 
