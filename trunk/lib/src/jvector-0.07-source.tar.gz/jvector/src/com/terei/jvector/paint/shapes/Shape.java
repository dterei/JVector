/*
 * Created By David Terei
 * With the Eclispe IDE
 * Created on 25/04/2004
 */
package com.terei.jvector.paint.shapes;

import java.awt.Color;
import java.awt.Graphics2D;


/**
 * Lays a few basic properties/methods that all shapes must have.
 * All drawing shapes subclass this class.
 * 
 * @author David Terei
 * @since 25/04/2004
 * @version 1
 */
public abstract class Shape {
    
    /**
     * Returns the fill color of the shape.
     * 
     * @return The fill color of the shape.
     */
    public abstract Color getFillColor();

    /**
     * Returns the outline color of the shape.
     * 
     * @return The outline color of the shape.
     */
    public abstract Color getOutlineColor();
    
    /**
     * Returns the fill opacity of the shape.
     */
    public abstract int getFillOpacity();
    
    /**
     * Returns the outline opacity of the shape.
     */
    public abstract int getOutlineOpacity();
    
    /**
     * Returns the name of the shape.
     * 
     * @return The name of the shape.
     */
    public String getShape() {
        return "Shape";
    }

    /**
     * Sets the fill colour of the shape.
     * 
     * @param color The colour to set the shape's fill to.
     */
    public abstract void setFillColor(Color color);
    
    /**
     * Sets the outline colour of the shape.
     * 
     * @param color The colour to set the shape's outline to.
     */
    public abstract void setOutlineColor(Color color);
    
    /**
     * Sets the opacity of the fill of the shape.
     * 
     * @param opacity The opacity to set.
     */
    public abstract void setFillOpacity(int opacity);
    
    /**
     * Sets the opacity of the outline of the shape.
     * 
     * @param opacity The opacity to set.
     */
    public abstract void setOutlineOpacity(int opacity);
    
    /**
     * The painting method for each shape.
     * 
     * @param g The graphics object to draw to.
     */
    public void paint(Graphics2D g) {
        
    }
    
}
