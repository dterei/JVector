/*
 * Created By David Terei
 * With the Eclispe IDE
 * Created on 2/05/2004
 */
package com.terei.jvector.paint.shapes;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Graphics2D;
import java.awt.geom.Point2D;


/**
 * This class stores all the information about a rectangle, and manages
 * its drawing.
 * 
 * @author David Terei
 * @since 2/05/2004
 * @version 1
 */
public class Rectangle extends Shape {
    
    /**
     * The top left coordiante of the rectangle.
     */
    protected Point2D.Double p1;
    /**
     * The dimensions (width, height) of the rectangle.
     */
    protected Point2D.Double dim;
    /**
	 * The outline colour of the rectangle.
	 */ 
    protected Color color_out = Color.black;
    /**
     * The fill colour of the rectangle.
     */
    protected Color color_in = Color.white;
    /**
     * The stroke/width of the outline of the rectangle.
     */
    protected int stroke = 1;
    /**
     * The opacity of the fill of the rectangle.
     */
    protected int opacity_in = 100;
    /**
     * The opacity of the outline of the rectangle.
     */
    protected int opacity_out = 100;
    /**
     * The rectangle to draw
     */
    protected MyRectangle2D rect;    
    
    /**
     * Create a new Rectangle.
     * 
     * @param p1 The top left coordiantes of the rectangle.
     * @param Stroke The stroke/width of the outline of the rectangle.
     */
    public Rectangle(Point2D.Double p1, int Stroke) {
        this(p1,new Point2D.Double(0,0),Stroke);        
    }
    
    /**
     * Create a new Rectangle.
     * 
     * @param p1 The top left coordiantes of the rectangle.
     * @param dim The dimensions (width, height) of the rectangle.
     * @param Stroke The stroke/width of the outline of the rectangle.     
     */    
    public Rectangle(Point2D.Double p1, Point2D.Double dim, int Stroke) {
        this.p1 = p1;
        this.dim = dim;
        stroke = Stroke;    
        createRectangle();
    }
    
    /**
     * Creates a new Rectnagle.
     * 
     * @see com.terei.jvector.paint.shapes.MyRectangle2D
     */
    private void createRectangle() {
        rect = new MyRectangle2D(p1.x, p1.y, dim.x, dim.y, stroke);
    }   
    
    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.Shape#paint(java.awt.Graphics)
     */
    public void paint(Graphics2D g) {
        Composite comp_orig = g.getComposite();
                
        //set the opacity.
        float i = (float)opacity_in/100;
        Composite alpha = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, i);
        g.setComposite(alpha);
        //set the color.
        g.setColor(color_in);
        //draw the fill.        
        rect.fill(g);
        
        
        //draw the outline.
        if (stroke>0) {
            //g.setStroke(new BasicStroke(stroke));        
            //set the opacity.
            i = (float)opacity_out/100;
            Composite alpha2 = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, i);
            g.setComposite(alpha2);
            //set the color.
            g.setColor(color_out);
            //draw the outline.            
            rect.draw(g);
        }
        //restore the original composite.        
        g.setComposite(comp_orig);
    }
    
    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.Shape#getOutlineColor()
     */
    public Color getOutlineColor() {
    	return color_out;
    }

    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.Shape#getFillColor()
     */
    public Color getFillColor() {
        return color_in;
    }    
    
    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.Shape#getFillOpacity()
     */
    public int getFillOpacity() {
        return opacity_in;
    }

    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.Shape#getOutlineOpacity()
     */
    public int getOutlineOpacity() {
        return opacity_out;        
    }

    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.Shape#getShape()
     */
    public String getShape() {
        return "Rectangle";
    }
    
    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.Shape#setOutlineColor(java.awt.Color)
     */
    public void setOutlineColor(Color color) {
        color_out = color;
    }

    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.Shape#setFillColor(java.awt.Color)
     */
	 public void setFillColor(Color color) {
	 	color_in = color;
	 }
    
    /**
     * Sets the point starting point (top left).
     * 
     * @param p The point to set it to.
     */    
    public void setP1(Point2D.Double p) {
        p1 = new Point2D.Double(p.x,p.y);    
        createRectangle();
    }
    
    /**
     * Sets the point diagonally opptisote the starting point of the line (top left).
     * 
     * @param p2 The point to set it to.
     */
    public void setP2(Point2D.Double p2) {
        dim.x = p2.x - p1.x;
        dim.y = p2.y - p1.y;       
        createRectangle();
    }      

    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.Shape#setFillOpacity(int)
     */
    public void setFillOpacity(int opacity) {
        opacity_in = opacity;
    }

    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.Shape#setOutlineOpacity(int)
     */
    public void setOutlineOpacity(int opacity) {
        opacity_out = opacity;
    }
        
}
