/*
 * Created By David Terei
 * With the Eclispe IDE
 * 
 * Created on 15/05/2004
 */
package com.terei.jvector.paint.shapes;

import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Composite;
import java.awt.Graphics2D;
import java.awt.geom.Point2D;


/**
 * This class stores all the information about a oval, and manages
 * its drawing.
 * 
 * @author David Terei
 * @since 15/05/2004
 * @version 1
 */
public class Oval extends Rectangle {
    
    /**
     * The oval to draw.
     */
    MyOval2D oval;

    /**
     * Create a new Oval.
     * 
     * @param p1 The top left corner of the oval.
     * @param Stroke The thickness of the outline of the oval.
     */
    public Oval(Point2D.Double p1, int Stroke) {
        super(p1, Stroke);
        createOval();
    }
    
    /**
     * Create a new Oval.
     * 
     * @param p1 The top left corner of the oval.
     * @param dim The dimension (width, height) of the oval.
     * @param Stroke The thickness of the outline of the oval.
     */
    public Oval(Point2D.Double p1, Point2D.Double dim, int Stroke) {
        super(p1,dim,Stroke);
        createOval();
    }
    
    /**
     * Create a new oval.
     * 
     * @param rect The rectangle to create the oval from.
     */
    public Oval(Rectangle rect) {
        super(rect.p1, rect.dim, rect.stroke);
        this.setFillColor(rect.getFillColor());
        this.setFillOpacity(rect.getFillOpacity());
        this.setOutlineColor(rect.getOutlineColor());
        this.setOutlineOpacity(rect.getOutlineOpacity());
        createOval();
    }
    
    /**
     * Creates a new Oval with the current values set.
     *
     * @see com.terei.jvector.paint.shapes.MyOval2D
     */
    private void createOval() {
        oval = new MyOval2D(this.p1.x, this.p1.y, this.dim.x, this.dim.y, this.stroke);
    }
    
    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.Shape#getShape()
     */
    public String getShape() {
        return "Oval";
    }
    
    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.Shape#paint(java.awt.Graphics)
     */
    public void paint(Graphics2D g) {
        Composite comp_orig = g.getComposite();        
        
        //createOval();
        
        //set the opacity.
        float i = (float)opacity_in/100;
        Composite alpha = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, i);
        g.setComposite(alpha);
        //set the color.
        g.setColor(color_in);
        //draw the fill. 
        oval.fill(g);
        
        //draw the outline.
        if (stroke>0) {
            g.setStroke(new BasicStroke(stroke));        
            //set the opacity.
            i = (float)opacity_out/100;
            Composite alpha2 = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, i);
            g.setComposite(alpha2);
            //set the color.
            g.setColor(color_out);
            //draw the outline.            
            oval.draw(g);
        }
        
        g.setComposite(comp_orig);
        
    }

    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.Rectangle#setP1(java.awt.geom.Point2D.Double)
     */
    public void setP1(Point2D.Double p) {
        super.setP1(p);
        createOval();
    }
    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.Rectangle#setP2(java.awt.geom.Point2D.Double)
     */
    public void setP2(Point2D.Double p2) {
        super.setP2(p2);
        createOval();
    }
}

