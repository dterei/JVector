/*
 * Created By David Terei
 * With the Eclispe IDE
 * 
 * Created on 16/05/2004
 */
package com.terei.jvector.paint;

import java.io.Serializable;
import java.util.Vector;


/**
 * This class provides the ability to save an image to JVector's native
 * format, which allows the image to be reopen, and worked on again.
 * 
 * This class stores all the information about an image, and it implements
 * the Serializable interface, so that it can be saved to a file through an
 * object output stream.
 * 
 * @author David Terei
 * @since 16/05/2004
 * @version 0.1
 */
public class ImageFile implements Serializable {

    /**
     * The signiture number for this class for use with serilization.
     * This number is normally generated on the fly by analyzing the
     * class and its fields. By manually specifing it, i am able to
     * change so parts of this class, while still allowing older saved
     * maps to remain compatible, as these id's must match with the saved
     * one and this class.
     */
    private static final long serialVersionUID = 843402619281875150L;
    
    private Vector shapes;
    
    /**
     * Create a new ImageFile.
     */
    public ImageFile(Vector shapes) {
        this.shapes = shapes;
    }

}
