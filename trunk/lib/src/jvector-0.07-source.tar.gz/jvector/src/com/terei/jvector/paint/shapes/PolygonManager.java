/*
 * Created By David Terei
 * With the Eclispe IDE
 * 
 * Created on 16/05/2004
 */
package com.terei.jvector.paint.shapes;

import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;

import javax.swing.JPanel;

import com.terei.jvector.GUI.ColorSelectedPanel;
import com.terei.jvector.GUI.options.RectangleOptions;


/**
 * Manages the operations for drawing a polygon.
 * 
 * @author David Terei
 * @since 16/05/2004
 * @version 1
 */
public class PolygonManager extends ShapeManager implements Runnable {
    
    /**
     * The maximum time in milliseconds between two clicks
     * for it to be registered as a double click.
     */
    private static final int DOUBLE_SPEED = 100;
    
    /**
     * Holds the Polygon this class works with.
     */
    protected Polygon poly;
    
    /**
     * Holds if a line is currently been drawn or not.
     */
    private boolean drawing = false;
    
    /**
     * Holds the amount of time between mouse clicks, used to test for double clicks.
     */
    private long time = DOUBLE_SPEED;
    
    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.ShapeManager#getOptionPanel()
     */
    public static JPanel getOptionPanel() {        
        return new RectangleOptions();
    }
    
    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.ShapeManager#mousePressed(java.awt.event.MouseEvent)
     */
    public void mousePressed(MouseEvent e) { 
        Point2D.Double p = new Point2D.Double(e.getPoint().x, e.getPoint().y);
        
        //test to see if a polygon is currently being drawn or not.
        if (!drawing) {
            
            //no, one isnt being draw, so create a new one.
            drawing = true;
            //create a new polygon.
            poly = new Polygon(p, RectangleOptions.getStroke());            
            poly.setFillColor(ColorSelectedPanel.getBackColor());
            poly.setFillOpacity(ColorSelectedPanel.getBackOpacity());
            poly.setOutlineColor(ColorSelectedPanel.getForeColor());
            poly.setOutlineOpacity(ColorSelectedPanel.getForeOpacity());
            //add a second point, for the one displayed when moving the mouse.
            poly.addPoint(p);
            
        } else {
            
            //polygon currently being draw, so lets add a point or finish it.
            //test for a double click.
            if (time<DOUBLE_SPEED) {
                //delete the last point, as it is an extra point serving
                //as a visual guide when moving the mouse.
                poly.deletePoint(poly.getLength()-1);
                //make sure there are at least 3 points (triangle)
                //if there are not, delete the shape.
                if (poly.getLength()<3) {
                    poly = null;
                }

                drawing = false;               
                return;
            }
            
            //reset the double click time.
            time = 0;
            //start the counting thread again.
            Thread thread = new Thread(this);
            thread.start();            
            //add a new point to the polygon.
            poly.addPoint(p);
            
        }
    }

    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.ShapeManager#mouseMoved(java.awt.event.MouseEvent)
     */
    public void mouseMoved(MouseEvent e) {
        if (drawing) {
            Point2D.Double p = new Point2D.Double(e.getPoint().x, e.getPoint().y);
            poly.setPoint(p, poly.getLength()-1);
        }
    }
    
    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.ShapeManager#getDone()
     */
    public boolean getDone() {
        return !drawing;
    }

    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.ShapeManager#getShape()
     */
    public Shape getShape() {
        return poly;
    }

    /* (non-Javadoc)
     * Serves as a simple timing thread, used to test for double clicks.
     * 
     * @see java.lang.Runnable#run()
     */
    public void run() {
        while(time<DOUBLE_SPEED) {
            try {
                Thread.sleep(1);
                time++;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

}
