/*
 * Created By David Terei
 * With the Eclispe IDE
 * Created on 21/04/2004
 */
package com.terei.jvector.GUI;

import javax.swing.text.*;

/**
 * This class extends PlainDocument, to override the documents insertString
 * method, to restrict hte string to insert to only containing ints, and not
 * letting the input field above it, exceed the length specified.
 * 
 * @see javax.swing.text.PlainDocument
 * 
 * @author David Terei
 * @since 16/12/03
 * @version 1
 */
public class IntDocument extends PlainDocument {
    
    /**
     * The current length in characters of the input field above this document.
     */
    private int length = 0;
    
    /**
     * The maximun amount of characters allowed in the input field above this
     * document.
     */
    private int max;
    
    /**
     * Create a new IntDocument of the length specified.
     * 
     * @param MaxLength
     *            The maximun length of characters that the document will
     *            accept.
     */
    public IntDocument(int MaxLength) {
        max = MaxLength;
    }
    
    /**
     * Overrides PlainDocument's insertString method to restrict only string
     * containing ints to be inserted into the text document.
     * 
     * @param offs the starting offset >= 0
     * @param str the string to insert; does nothing with null/empty strings
     * @param a the attributes for the inserted content
     * @exception BadLocationException the given insert position is not a 
     * 									valid position within the document
     * @see javax.swing.text.PlainDocument#insertString
     */
    public void insertString(int offs, String str, AttributeSet a)
    									throws BadLocationException {
        if (str == null) return;        
        char[] org = str.toCharArray();        
        length = super.getLength();
        
        for (int i = 0; i < org.length; i++)
            if (!Character.isDigit(org[i]) || max == length + i) return;
            
        super.insertString(offs, new String(org), a);
    }
    
}