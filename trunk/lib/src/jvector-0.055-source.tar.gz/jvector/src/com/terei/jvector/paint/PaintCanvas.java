/*
 * Created By David Terei
 * With the Eclispe IDE
 * Created on 24/04/2004
 */
package com.terei.jvector.paint;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.Vector;

import javax.swing.JPanel;

import com.terei.jvector.paint.shapes.LineManager;
import com.terei.jvector.paint.shapes.RectangleManager;
import com.terei.jvector.paint.shapes.Shape;


/**
 * Provides The actual 'paint canvas' a JPanel that the
 * user interacts with directly to draw shapes. This class
 * passes on the draw commands to lower subclasses, and 
 * displays the results. This is the GUI frontend.
 * 
 * @author David Terei
 * @since 24/04/2004
 * @version 0.4
 */
public class PaintCanvas extends JPanel implements MouseListener, 
											MouseMotionListener {
    
    public PaintCanvas() {      
        this.addMouseListener(this);
        this.addMouseMotionListener(this);
        this.setBackground(Color.WHITE);     
    }
    
    /**
     * The class which manages the drawing of a line.
     */
    private static LineManager lineM = new LineManager();
    
    /**
     * The class which manages the drawing of a rectangle.
     */
    private static RectangleManager rectM = new RectangleManager();
    
    /**
     * The current Tool.
     */
    private static int TOOL;
    /**
     * The value for no tool.
     */
    public static final int TOOL_NULL = 0;
    
    /**
     * The value for the line tool.
     */
    public static final int TOOL_LINE = 1;
    
    /**
     * The value for the rectangle tool.
     */
    public static final int TOOL_RECT = 2;
    
    /**
     * The value for when the canvas is idle
     * (not currently in any draw operation).
     */
    public static final int MODE_IDLE = 0;
    /**
     * The value for when the canvas is active
     * (currently in a draw operation).
     */
    public static final int MODE_ACT = 1;
    /**
     * The state of the canvas, active or idle.
     */
    private static int MODE = 0;
    
    /**
     * The cursors for all the tools.
     */
    private static final Cursor[] Cursors = new Cursor[3];    

	/**
	 * Holds all the shapes that have been drawn.
	 */
	private Vector shapes = new Vector(); 
	
	/**
	 * Holds the shape currently being drawn.
	 */
	private Shape shape;

    /**
     * Static initialization block.
     * Loads all the cursors required for the various tools.
     */
    static {
        try {
            Cursors[0] = new Cursor(Cursor.DEFAULT_CURSOR);
            Cursors[1] = new Cursor(Cursor.CROSSHAIR_CURSOR); 
            Cursors[2] = new Cursor(Cursor.CROSSHAIR_CURSOR);
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
     * @return Returns the mODE.
     */
    public static int getMode() {
        return MODE;
    }
    
    /**
     * @return Returns the tOOL.
     */
    public static int getTool() {
        return TOOL;
    }
    
    /**
     * Sets the tool.
     * 
     * @param tool The tool to set the canvas to use.
     */
    public static void setTool(int tool) {
    	if(MODE==MODE_IDLE)
    		TOOL = tool;    	
    }

    /* (non-Javadoc)
     * @see java.awt.event.MouseListener#mouseClicked(java.awt.event.MouseEvent)
     */
    public void mouseClicked(MouseEvent e) {                
    }

    /* (non-Javadoc)
     * @see java.awt.event.MouseListener#mouseEntered(java.awt.event.MouseEvent)
     */
    public void mouseEntered(MouseEvent e) {
        this.setCursor(Cursors[TOOL]);          
    }

    /* (non-Javadoc)
     * @see java.awt.event.MouseListener#mouseExited(java.awt.event.MouseEvent)
     */
    public void mouseExited(MouseEvent e) {
        this.setCursor(Cursors[TOOL_NULL]);        
    }

    /* (non-Javadoc)
     * @see java.awt.event.MouseListener#mousePressed(java.awt.event.MouseEvent)
     */
    public void mousePressed(MouseEvent e) {
        Point p = e.getPoint();
        
        switch(TOOL) {
          	case TOOL_NULL: ; break;
            case TOOL_LINE: lineM.mousePressed(e); handleLine(); break;
            case TOOL_RECT: rectM.mousePressed(e); handleRect(); break;
        }
    }

    /* (non-Javadoc)
     * @see java.awt.event.MouseListener#mouseReleased(java.awt.event.MouseEvent)
     */
    public void mouseReleased(MouseEvent e) {        
    }

    /* (non-Javadoc)
     * @see java.awt.event.MouseMotionListener#mouseDragged(java.awt.event.MouseEvent)
     */
    public void mouseDragged(MouseEvent e) {   
    }

    /* (non-Javadoc)
     * @see java.awt.event.MouseMotionListener#mouseMoved(java.awt.event.MouseEvent)
     */
    public void mouseMoved(MouseEvent e) {
        if(MODE==MODE_ACT) {
            
            switch(TOOL) {
          		case TOOL_NULL: ; break;
          		case TOOL_LINE: lineM.mouseMoved(e); handleLine(); break;
          		case TOOL_RECT: rectM.mouseMoved(e); handleRect(); break;
            }
            
        }
    }
    
    /**
	 * Handles the operations required to draw a line.
	 */
    private void handleLine() {
        MODE = MODE_ACT;
        shape = lineM.getShape();
        if(lineM.getDone()) {
           shapes.add(shape);
           MODE = MODE_IDLE;
        }
        repaint();
    }
    
    /**
	 * Handles the operations required to draw a rectangle.
	 */
    private void handleRect() {
        MODE = MODE_ACT;
        shape = rectM.getShape();
        if(rectM.getDone()) {
           shapes.add(shape);
           MODE = MODE_IDLE;
        }
        repaint();
    }
    
    /**
     * Paints the canvas.
     */
    public void paintComponent(Graphics g) {
    	super.paintComponent(g);
    	//cast the standard graphics to a Graphics2D.
    	Graphics2D g2 = (Graphics2D)g;
    	
    	//turn Antialiasing on.
    	g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    	
    	//draw all the shapes.
    	for(int i=0; i<shapes.size(); i++) {
    		Shape shape = (Shape)shapes.get(i);
    		shape.paint(g2);    		
    	}
    	//draw the currently active shape.
    	if(shape!=null)
    	    shape.paint(g2);
    }

}
