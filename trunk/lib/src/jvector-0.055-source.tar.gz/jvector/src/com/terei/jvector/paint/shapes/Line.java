/*
 * Created By David Terei
 * With the Eclispe IDE
 * Created on 25/04/2004
 */
package com.terei.jvector.paint.shapes;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Point2D;


/**
 * This class stores all the information about a line, and manages
 * its drawing.
 * 
 * @author David Terei
 * @since 25/04/2004
 * @version 0.5
 */
public class Line extends Shape {

    /**
     * The starting coordinates of the line.
     */
    private Point2D.Double p1;
    /**
     * The enidng coordinates of the line.
     */
    private Point2D.Double p2;
    /**
     * The colour of the line.
     */
    private Color color;
    /**
     * The stroke/width of the line.
     */
    private int stroke = 1;
    
    /**
     * Create a new line.
     * 
     * @param p1 The starting point of the line.
     * @param Stroke The stroke/width of the line.
     */
    public Line(Point2D.Double p1, int Stroke, Color color) {
        this(p1,p1,Stroke, color);        
    }
    
    /**
     * Create a new line.
     * 
     * @param p1 The starting point of the line.
     * @param p2 The ending point of the line.
     * @param Stroke The stroke/width of the line.
     */    
    public Line(Point2D.Double p1, Point2D.Double p2, int Stroke, Color color) {
        this.p1 = p1;
        this.p2 = p2;
        stroke = Stroke;
        this.color = color;
    }    
    
    /**
     * @return Returns The starting point of the line.
     */
    public Point2D.Double getP1() {
        return p1;
    }
    /**
     * @return Returns The end point of the line.
     */
    public Point2D.Double getP2() {
        return p2;
    }

    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.Shape#getShape()
     */
    public String getShape() {
        return "Line";
    }
    
    /**
     * Get the thickness of the line.
     * 
     * @return Returns The stroke(thickness).
     */
    public int getStroke() {
        return stroke;
    }
    
    /**
     * Sets the coordinate of the line.
     * 
     * @param p1 The starting coordinate of the line.
     * 
     * @param p2 The ending coordinate of the line.
     */
    public void setCordinates(Point2D.Double p1, Point2D.Double p2) {
        this.p1 = p1;
        this.p2 = p2;
    }
    
    /**
     * Sets the coordinate of the line.
     * 
     * @param x1 The starting x coordinate of the line.
     * @param y1 The starting y coordinate of the line.
     * @param x2 The ending x coordinate of the line.
     * @param y2 The ending y coordinate of the line.
     */
    public void setCoordinates(double x1, double y1, double x2, double y2) {
        p1 = new Point2D.Double(x1,y1);
        p2 = new Point2D.Double(x2,y2);
    }
    
    /**
     * Set the starting point of the line.
     * 
     * @param p1 The starting point.
     */
    public void setP1(Point2D.Double p1) {
        this.p1 = p1;
    }
    /**
     * Set the ending point of the line.
     * 
     * @param p2 The ending point.
     */
    public void setP2(Point2D.Double p2) {
        this.p2 = p2;
    }
    
    /**
     * Set the thickness of the line.
     * 
     * @param stroke The stroke to set (thickness).
     */
    public void setStroke(int stroke) {
        this.stroke = stroke;
    }

    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.Shape#paint(java.awt.Graphics)
     */
    public void paint(Graphics2D g) {
        g.setColor(color);
        g.setStroke(new BasicStroke(stroke));
        g.drawLine((int)p1.x,(int)p1.y,(int)p2.x,(int)p2.y);
    }

    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.Shape#getFillColor()
     */
    public Color getFillColor() {
        return color;
    }

    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.Shape#getOutlineColor()
     */
    public Color getOutlineColor() {
        return getFillColor();
    }

    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.Shape#setFillColor(java.awt.Color)
     */
    public void setFillColor(Color color) {
        this.color = color;        
    }

    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.Shape#setOutlineColor(java.awt.Color)
     */
    public void setOutlineColor(Color color) {
        setFillColor(color);
    }
    
}
