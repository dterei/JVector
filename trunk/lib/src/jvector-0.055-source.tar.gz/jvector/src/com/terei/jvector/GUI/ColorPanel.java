//TODO Doc
/*
 * Created By David Terei
 * With the Eclispe IDE
 * 
 * Created on 7/05/2004
 */
package com.terei.jvector.GUI;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.net.URI;
import java.net.URL;
import java.util.ResourceBundle;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

import com.terei.jvector.JVector;


/**
 * Creates a panel that allows the user to set a foreground and background 
 * colour using swatches (<code>com.terei.jvector.GUI.ColourSwatch</code>)
 * and some tools to manipulate these swatches. 
 * 
 * @author David Terei
 * @since 7/05/2004
 * @version 0.1
 */
public class ColorPanel extends JPanel implements ActionListener {
    
    public static int WIDTH = 194;
    public static int HEIGHT = 260;
    
    private ResourceBundle rbLocale;
    
    private JButton jbAddSwatch;
    private JButton jbRemSwatch;
    private JButton jbInfSwatch;
    
    private JTabbedPane jtpSwatch;
    private static final String SWATCH_PATH = "Resources/Swatches";
    
    /**
     * Create a new ColourPanel.
     * 
     * @param bundle The resource bundle to use for the strings/locale of this panel.
     */
    public ColorPanel(ResourceBundle bundle) {
        super(new BorderLayout(), true);
        rbLocale = bundle;
        initGUI();
        loadSwatches();
    }
    
    
    /**
     * Initialises the GUI.
     */
    private void initGUI() {
        jbAddSwatch = createButton("Resources/new.png", 
                		rbLocale.getString("ColorPanel.AddSwatch"));
        jbRemSwatch = createButton("Resources/bin.png", 
    						rbLocale.getString("ColorPanel.RemSwatch"));
        jbInfSwatch = createButton("Resources/info.png", 
        					rbLocale.getString("ColorPanel.InfSwatch"));
        
        JPanel jpTop = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 7));
        jpTop.add(jbAddSwatch);
        jpTop.add(jbRemSwatch);
        jpTop.add(jbInfSwatch);
        
        jtpSwatch = new JTabbedPane();
        
        JPanel jpMid = new JPanel(new BorderLayout());
        jpMid.add(jtpSwatch);
        
        JPanel jpBot = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 7));
        jpBot.add(new ColorSelectedPanel());        
        
        this.setMaximumSize(new Dimension(WIDTH,HEIGHT));
        this.add(jpTop,BorderLayout.NORTH);
        this.add(jpMid,BorderLayout.CENTER);
        this.add(jpBot,BorderLayout.SOUTH);
    }
    
    private JButton createButton(String icon, String tooltip) {
        JButton button = new JButton(JVector.loadImageIcon(icon));
        //TODO the tooltips
        button.setToolTipText(tooltip);
        button.setPreferredSize(new Dimension(20,20));
        button.setContentAreaFilled(false);
        button.addActionListener(this);
        
        return button;
        
    }   
    
    private void loadSwatches() {
        File[] files =getSwatches();
        for (int i=0; i<files.length; i++) {
            JPanel panel = new ColorSwatch(files[i].getPath());
            jtpSwatch.addTab(panel.getName(), panel);
        }
    }
    
    private File[] getSwatches() {
        File[] list = new File[1];
        try {
	        URL url = JVector.class.getClassLoader().getResource(SWATCH_PATH);
	        URI uri = new URI(url.toExternalForm());
	        File dir = new File(uri);
	        list = dir.listFiles(new MyFileFilter("properties",false));
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return list;
    }


    /* (non-Javadoc)
     * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
     */
    public void actionPerformed(ActionEvent e) {
        Object src = e.getSource();
        
        if (src.equals(jbInfSwatch)) {
            ColorSwatch swatch = (ColorSwatch)jtpSwatch.getSelectedComponent();
            swatch.showInfoDialog();
        }
    }
  
}