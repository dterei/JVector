package com.terei.jvector.util;

/**
 * This class stores an array of ints, but provides dynamic functions
 * to add, and remove values from the array. The array can also grow as
 * nesseccary.
 * 
 * @author David Terei
 * @since 16/05/2004
 * @version 1
 */
public class DynamicIntArray {

    /**
     * An Array of Ints to hold the integers.
     */
    private int[] data;

    /**
     * Create a new DynamicIntArray.
     */
    public DynamicIntArray() {
        //Initialize the array to hold 1 int, will grow as nessecary.
        data = new int[1];
    }

    /**
     * Returns all of the array.
     *
     * @return The int Array
     */
    public int[] getAll() {
        return data;
    }

    /**
     * Returns the length of the array.
     *
     * @return The length of the array
     */
    public int length() {
        return data.length;
    }

    /**
     * Returns the int at the posistion given in the array, if it is outside
     * the arrays boundary, then -99 is returned.
     *
     * @param position The Posistion in the array of the int you want returned.
     *                  If it doesnt exist, -99 is returned.
     * @return The int requested.
     */
    public int get(int position) {
        if (position >= data.length)
            return -99;
        else
            return data[position];
    }

    /**
     * Increase the array length by one, and place the value
     * Specified in this posistion
     *
     * @param value An int which you want to store in the array.
     */
    public void add(int value) {
        //Create A new Array, 1 size bigger.
        int[] newData = new int[data.length+1];
        //Copy the old array into the new array.
        System.arraycopy(data, 0, newData, 0, data.length);
        //Reference the old array to the new array.
        data = newData;
        //Now add in the value
        data[data.length-1] = value;
    }

    /**
     * Store the value in the specified position in the array.
     * The data array will increase in size to include this
     * position, if necessary.
     *
     * @param position The posistion in the array you want to value.
     * @param value An int which you want to store in the array.
     */
    public void add(int value,int position) {
        if (position >= data.length) {
            // The specified position is outside the actual size of
            // the data array. Set the array Size to be the size of
            // posistion.
            int[] newData = new int[position+1];
            System.arraycopy(data, 0, newData, 0, data.length);
            data = newData;
        }
        //Now we know the array is big enough, so we store the value given.
        data[position] = value;
    }

    /**
     * Delete the last value in the array, by reducing the array length
     *
     * @return If the operation was sucessful or not.
     */
     public boolean delete() {
        //First, create a new array one length less to hold the new array.
        int[] newData = new int[data.length-1];
        System.arraycopy(data,0,newData,0,newData.length);
        data = newData;
        return true;
     }

    /**
     * Delete the value at the posistion specified, reducing the array appropriatley.
     *
     * @param posistion The posistion of the array element to delete.
     * @return If the operation was sucessful or not.
     */
     public boolean delete(int posistion) {
        //Check that the posistion given is within the bounds of the array.
        if (posistion > data.length)
            //Return that the operation didnt take place.
            return false;
        //Now we know that the posistion given must be within the bounds of data
        //First, create a new array one length less to hold the new array.
        int[] newData = new int[data.length-1];
        System.arraycopy(data,0,newData,0,posistion-1);
        System.arraycopy(data,posistion-1,newData,posistion,newData.length);
        data = newData;
        return true;
     }

     /**
      * Sets this array to equal the speccified array, exactly.
      *
      * @param ints The array you want to set this array to be equal to.
      */
     public void equals(int[] ints) {
        data = null;
        data = new int[ints.length];
        data = ints;
     }
}