/*
 * Created By David Terei
 * With the Eclispe IDE
 * Created on 26/04/2004
 */
package com.terei.jvector.paint.shapes;

import java.awt.Color;
import java.awt.Point;
import java.awt.event.MouseEvent;

import javax.swing.JPanel;

import com.terei.jvector.GUI.ColorSelectedPanel;
import com.terei.jvector.GUI.options.LineOptions;


/**
 * Manages the operations for drawing a line.
 * 
 * @author David Terei
 * @since 26/04/2004
 * @version 1
 */
public class LineManager extends ShapeManager {
    
    /**
     * The line drawn.
     * 
     * @see Line
     */
    private Line line;
    
    /**
     * If a line is currently being drawn. 
     */
    private boolean drawing = false;

    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.ShapeManager#getOptionPanel()
     */ 
    public static JPanel getOptionPanel() {
        JPanel panel = new LineOptions();
        
        return panel;
    }
    
    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.ShapeManager#mousePressed(java.awt.event.MouseEvent)
     */
    public void mousePressed(MouseEvent e) {
        Point p = e.getPoint();
        if (!drawing) {
            Color color = ColorSelectedPanel.getForeColor();
            int opacity = ColorSelectedPanel.getForeOpacity();
            line = new Line(p,LineOptions.getStroke(),color, opacity);
            drawing = true;
        } else {
            line.setP2(p);
            drawing = false;
        }
        
    }

    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.ShapeManager#mouseMoved(java.awt.event.MouseEvent)
     */
    public void mouseMoved(MouseEvent e) {
        Point p = e.getPoint();       
        if (drawing && line != null)
            line.setP2(p);
    }

    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.ShapeManager#getDone()
     */
    public boolean getDone() {
        return !drawing;
    }

    /* (non-Javadoc)
     * @see com.terei.jvector.paint.shapes.ShapeManager#getShape()
     */
    public Shape getShape() {
        return line;
    }

}
