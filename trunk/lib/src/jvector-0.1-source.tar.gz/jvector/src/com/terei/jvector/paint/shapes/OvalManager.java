/*
 * Created By David Terei
 * With the Eclispe IDE
 * 
 * Created on 15/05/2004
 */
package com.terei.jvector.paint.shapes;


/**
 * Manages the operations for drawing a oval.
 * 
 * @author David Terei
 * @since 15/05/2004
 * @version 0.1
 */
public class OvalManager extends RectangleManager {
    
    
    /**
     * Overide the getShape() method of RectangleManager
     * to instead return an oval.
     * 
     * @see com.terei.jvector.paint.shapes.RectangleManager#getShape()
     */
    public Shape getShape() {
        Rectangle rect = (Rectangle)super.getShape();
        Oval oval = new Oval(rect);
        return oval;
    }
    
}
