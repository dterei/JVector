/*
 * Created By David Terei
 * With the Eclispe IDE
 * 
 * Created on 17/05/2004
 */
package com.terei.jvector.paint.shapes;


/**
 * 
 * 
 * @author David Terei
 * @since 17/05/2004
 * @version 0.1
 */
public class TextManager {

    /**
     * 
     */
    public TextManager() {
        super();
        // TODO TextManager
    }

}
