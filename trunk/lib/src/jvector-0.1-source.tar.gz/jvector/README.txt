Thankyou for your interest in JVector.
This file explains some brief general information of JVector, 
and the process needed to build and run JVector.

-------
JVector
-------
JVector is a Vector (wow!) based paint program. It aims to currently
provide fairly simple tools, simliar to MS Paint, but being Vector based.
New and exciting features, such as texturing, are more important then advance
node editing for this project.

JVector is written in, you guessed it, Java! The project is hosted on 
sourceforge.net (http://sourceforge.net/projects/t-bone-paint). This project
is an open source project of course, under the GPL (GNU General Public Licence).

------------
Requirnments
------------
* Java VM 1.4.2 (Probally works on lower JRE, but not tested).
* Ant 1.6.1 (Probally works on lower versions, but not tested).
            (Ant is not actually needed, but will handle the build
             process for you.)
* Assumed understanding of how to use Ant.

If you fail these requirnments, then you really shouldn't be trying to build your own CVS
version. Binary builds wil be provided on a regular basis.

------------------
Build File Targets
------------------
* compile - Compiles the program, this target should be used to generate a binary version
            of JVector Initially.
* clean - Deletes all the files in the build (bin) directory, except those in the Resources folder.
* build - Cleans and then compiles JVector.
* jar - Packages Le Paint into a self executable jar archive, ("lib/JVector.jar").
* run - Runs JVector.
* run-jar - Runs the jar packaged version of the program, ("lib/JVector.jar").
* pack - Creates a compressed tar archive (tar.gz) containing the source code and documentation
         for it (JVector-${version}-source.tar.gz).
* javadoc - Builds the JavaDoc for JVector, placing it in the "doc" directory.
* run-viewdoc - Attempts to launch Internet Explorer, and view the javadoc. (Only works on Windows (XP?)).